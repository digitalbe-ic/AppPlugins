(function () {
    'use strict';

    function element(tag, className, value) {
        const node = document.createElement(tag);
        if (className) node.className = className;
        if (value !== undefined) node.textContent = String(value);
        return node;
    }

    function uuid() {
        if (window.crypto && typeof window.crypto.randomUUID === 'function') return window.crypto.randomUUID();
        const bytes = new Uint8Array(16);
        if (window.crypto && window.crypto.getRandomValues) window.crypto.getRandomValues(bytes);
        else for (let i = 0; i < bytes.length; i++) bytes[i] = Math.floor(Math.random() * 256);
        bytes[6] = (bytes[6] & 15) | 64;
        bytes[8] = (bytes[8] & 63) | 128;
        const hex = Array.from(bytes, (n) => n.toString(16).padStart(2, '0')).join('');
        return [hex.slice(0, 8), hex.slice(8, 12), hex.slice(12, 16), hex.slice(16, 20), hex.slice(20)].join('-');
    }

    function message(node, value, error) {
        if (!node) return;
        node.textContent = value || '';
        node.hidden = !value;
        node.classList.toggle('bwb-error', Boolean(error));
        node.setAttribute('role', error ? 'alert' : 'status');
    }

    let initialTracking = null;
    if (window.location.hash.indexOf('#bwb-track=') === 0) {
        const secret = window.location.hash.slice(11);
        const split = secret.indexOf('.');
        if (split > 0) {
            try {
                initialTracking = { reference: decodeURIComponent(secret.slice(0, split)), token: decodeURIComponent(secret.slice(split + 1)) };
            } catch (e) { /* Leave manual tracking available for malformed links. */ }
        }
        if (window.history && window.history.replaceState) {
            window.history.replaceState(null, '', window.location.pathname + window.location.search);
        }
    }

    document.querySelectorAll('[data-bwb-app]').forEach(function (app, appIndex) {
        let config;
        try { config = JSON.parse(app.dataset.config); } catch (e) { return; }
        const money = (minor, currency) => (currency || config.currency) + ' ' + (Number(minor) / 100).toFixed(2);
        const form = app.querySelector('[data-order-form]');
        const trackForm = app.querySelector('[data-track-form]');
        const bookingMessage = app.querySelector('[data-message]');
        const trackingMessage = app.querySelector('[data-track-message]');
        const success = app.querySelector('[data-success]');
        const trackingResult = app.querySelector('[data-tracking-result]');
        const products = new Map(config.products.map((product) => [product.id, product]));
        let requestKey = uuid();
        let submitting = false;

        async function readResponse(response) {
            let result;
            try { result = await response.json(); } catch (e) { throw new Error('The server could not complete your request. Please try again shortly.'); }
            if (!response.ok) throw new Error(result.message || 'The request could not be completed. Please try again.');
            return result;
        }

        async function api(path, body) {
            let session;
            try {
                const url = new URL(config.sessionUrl, window.location.href);
                url.searchParams.set('_bwb', Date.now().toString());
                session = await readResponse(await fetch(url.toString(), { credentials: 'same-origin', cache: 'no-store', headers: { Accept: 'application/json' } }));
            } catch (error) {
                throw new Error(error.message || 'Could not start a secure session. Please reload and try again.');
            }
            if (!session.nonce) throw new Error('Could not start a secure session. Please reload and try again.');
            try {
                return await readResponse(await fetch(config.api + path, {
                    method: 'POST', credentials: 'same-origin', cache: 'no-store',
                    headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': session.nonce, Accept: 'application/json' },
                    body: JSON.stringify(body)
                }));
            } catch (error) {
                if (error instanceof TypeError) throw new Error('The connection was interrupted. If you submitted an order, check your confirmation email or contact the supplier before trying again.');
                throw error;
            }
        }

        function quantities() {
            if (!form) return [];
            return Array.from(form.querySelectorAll('[data-product]')).map(function (row) {
                const input = row.querySelector('[data-quantity]');
                const amount = Math.min(99, Math.max(0, Math.floor(Number(input.value) || 0)));
                return { product_id: row.dataset.product, quantity: amount };
            }).filter((line) => line.quantity > 0);
        }

        function summary() {
            if (!form) return;
            const lines = quantities();
            const list = app.querySelector('[data-cart-lines]');
            list.replaceChildren();
            let subtotal = 0;
            lines.forEach(function (line) {
                const product = products.get(line.product_id);
                if (!product) return;
                const lineTotal = line.quantity * Number(product.price_minor);
                subtotal += lineTotal;
                const row = element('div', 'bwb-cart-line');
                row.append(element('span', '', line.quantity + ' × ' + product.name), element('strong', '', money(lineTotal)));
                list.append(row);
            });
            if (!lines.length) list.append(element('p', 'bwb-muted', 'Add some water to get started.'));
            app.querySelector('[data-subtotal]').textContent = money(subtotal);
            app.querySelector('[data-delivery]').textContent = money(config.deliveryFee);
            app.querySelector('[data-total]').textContent = money(lines.length ? subtotal + Number(config.deliveryFee) : 0);
            form.querySelector('[data-submit]').disabled = !lines.length || submitting;
        }

        function orderCard(order, destination) {
            destination.replaceChildren();
            const heading = element('div', 'bwb-order-heading');
            heading.append(element('h3', '', 'Order ' + order.reference), element('span', 'bwb-status', config.statuses[order.status] || order.status));
            destination.append(heading);
            if (order.status === 'cancelled') {
                destination.append(element('p', 'bwb-order-context', 'This order has been cancelled. Contact the supplier if you need help.'));
            } else {
                const steps = ['pending', 'confirmed', 'out_for_delivery', 'delivered'];
                const current = steps.indexOf(order.status);
                const progress = element('ol', 'bwb-progress');
                steps.forEach(function (status, index) {
                    const step = element('li', index <= current ? 'bwb-complete' : '', config.statuses[status]);
                    if (index === current) step.setAttribute('aria-current', 'step');
                    progress.append(step);
                });
                destination.append(progress);
            }
            const delivery = element('div', 'bwb-order-delivery');
            delivery.append(element('strong', '', order.delivery_date), element('span', '', order.delivery_slot));
            destination.append(delivery);
            (order.items || []).forEach(function (line) {
                const row = element('div', 'bwb-summary-row');
                row.append(element('span', '', line.quantity + ' × ' + line.name), element('strong', '', money(line.line_total_minor, order.currency)));
                destination.append(row);
            });
            const fee = element('div', 'bwb-summary-row');
            fee.append(element('span', '', 'Delivery'), element('span', '', money(order.delivery_fee_minor, order.currency)));
            const total = element('div', 'bwb-total');
            total.append(element('span', '', 'Total'), element('strong', '', money(order.total_minor, order.currency)));
            destination.append(fee, total, element('p', 'bwb-muted', order.payment_status === 'paid' ? 'Payment received.' : 'Payment due on delivery.'));
            destination.hidden = false;
        }

        async function track(reference, token) {
            const button = trackForm.querySelector('button');
            button.disabled = true;
            message(trackingMessage, 'Looking up your delivery…', false);
            trackingResult.hidden = true;
            try {
                const result = await api('track', { reference: reference.trim(), token: token.trim() });
                orderCard(result.order, trackingResult);
                message(trackingMessage, '', false);
                trackingResult.focus({ preventScroll: true });
            } catch (error) {
                message(trackingMessage, error.message, true);
            } finally { button.disabled = false; }
        }

        if (trackForm) {
            trackForm.addEventListener('submit', function (event) {
                event.preventDefault();
                if (!trackForm.reportValidity()) return;
                track(trackForm.elements.reference.value, trackForm.elements.token.value);
            });
            if (appIndex === 0 && initialTracking) {
                trackForm.elements.reference.value = initialTracking.reference;
                trackForm.elements.token.value = initialTracking.token;
                track(initialTracking.reference, initialTracking.token);
                app.querySelector('.bwb-tracking').scrollIntoView({ block: 'start' });
            }
        }

        if (!form) return;
        form.querySelectorAll('[data-product]').forEach(function (row) {
            const input = row.querySelector('[data-quantity]');
            row.querySelectorAll('[data-quantity-change]').forEach(function (button) {
                button.addEventListener('click', function () {
                    input.value = String(Math.min(99, Math.max(0, (parseInt(input.value, 10) || 0) + Number(button.dataset.quantityChange))));
                    summary();
                });
            });
            input.addEventListener('input', summary);
            input.addEventListener('change', function () {
                input.value = String(Math.min(99, Math.max(0, Math.floor(Number(input.value) || 0))));
                summary();
            });
        });
        summary();

        form.addEventListener('submit', async function (event) {
            event.preventDefault();
            if (submitting || !form.reportValidity()) return;
            const items = quantities();
            if (!items.length) { message(bookingMessage, 'Please choose at least one bottle or pack.', true); return; }
            const body = { items: items, request_key: requestKey };
            ['customer_name', 'email', 'phone', 'postcode', 'address', 'delivery_date', 'delivery_slot', 'notes', 'website'].forEach((key) => { body[key] = form.elements[key].value; });
            submitting = true;
            const button = form.querySelector('[data-submit]');
            button.textContent = 'Placing your order…';
            summary();
            message(bookingMessage, '', false);
            try {
                const result = await api('orders', body);
                requestKey = uuid();
                success.replaceChildren();
                success.append(element('div', 'bwb-success-tick', '✓'), element('p', 'bwb-eyebrow', 'THANK YOU FOR YOUR ORDER'), element('h3', '', 'Your water is on our list.'), element('p', '', 'Save your private tracking details below. Your supplier will confirm the delivery.'));
                const card = element('div', 'bwb-confirmation-card');
                orderCard(result.order, card);
                success.append(card);
                const credentials = element('div', 'bwb-credentials');
                const reference = element('p', '', 'Order reference: ' + result.order.reference);
                const keyLabel = element('label', '', 'Private tracking key');
                const keyInput = element('input');
                keyInput.type = 'text'; keyInput.readOnly = true; keyInput.value = result.token; keyInput.addEventListener('focus', () => keyInput.select());
                keyLabel.append(keyInput);
                const privateNote = element('p', 'bwb-fine-print', 'Keep this key private. Anyone with it can view this order’s delivery status and items.');
                const link = new URL(window.location.href);
                link.hash = 'bwb-track=' + encodeURIComponent(result.order.reference) + '.' + encodeURIComponent(result.token);
                const actions = element('div', 'bwb-success-actions');
                const trackingLink = element('a', 'bwb-button bwb-button-secondary', 'Open tracking link');
                trackingLink.href = link.toString(); trackingLink.rel = 'noreferrer';
                trackingLink.addEventListener('click', function (clickEvent) {
                    clickEvent.preventDefault();
                    trackForm.elements.reference.value = result.order.reference;
                    trackForm.elements.token.value = result.token;
                    track(result.order.reference, result.token);
                    app.querySelector('.bwb-tracking').scrollIntoView({ behavior: 'smooth', block: 'start' });
                });
                const copyButton = element('button', 'bwb-button bwb-button-secondary', 'Copy tracking link');
                copyButton.type = 'button';
                const copyStatus = element('span', 'bwb-copy-status'); copyStatus.setAttribute('aria-live', 'polite');
                copyButton.addEventListener('click', async function () {
                    try {
                        if (!navigator.clipboard) throw new Error('unavailable');
                        await navigator.clipboard.writeText(link.toString()); copyStatus.textContent = 'Link copied.';
                    } catch (error) { copyStatus.textContent = 'Copy the private key above, or save the tracking link using your browser.'; }
                });
                actions.append(trackingLink, copyButton);
                credentials.append(reference, keyLabel, privateNote, actions, copyStatus);
                success.append(credentials);
                const another = element('button', 'bwb-new-order', 'Place another order'); another.type = 'button';
                another.addEventListener('click', function () { form.hidden = false; success.hidden = true; form.scrollIntoView({ behavior: 'smooth', block: 'start' }); });
                success.append(another);
                trackForm.elements.reference.value = result.order.reference;
                trackForm.elements.token.value = result.token;
                success.hidden = false;
                form.hidden = true;
                form.reset();
                success.focus({ preventScroll: true });
                success.scrollIntoView({ behavior: 'smooth', block: 'start' });
            } catch (error) {
                message(bookingMessage, error.message, true);
                bookingMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
            } finally {
                submitting = false;
                button.replaceChildren(document.createTextNode('Place my order '), element('span', '', '→'));
                summary();
            }
        });
    });
}());

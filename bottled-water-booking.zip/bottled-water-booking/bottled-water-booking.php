<?php
/**
 * Plugin Name: AquaRoute – Bottled Water Booking & Supply
 * Description: Customer water bookings and a supplier dashboard for order and delivery management. Includes private tracking, cash on delivery and CSV exports.
 * Version: 1.0.0
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * Author: AquaRoute
 * License: GPL-2.0-or-later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: bottled-water-booking
 */

defined( 'ABSPATH' ) || exit;

define( 'BWB_VERSION', '1.0.0' );
define( 'BWB_FILE', __FILE__ );
define( 'BWB_DIR', plugin_dir_path( __FILE__ ) );
define( 'BWB_URL', plugin_dir_url( __FILE__ ) );

require_once BWB_DIR . 'includes/class-store.php';
require_once BWB_DIR . 'includes/class-frontend.php';
require_once BWB_DIR . 'includes/class-admin.php';
require_once BWB_DIR . 'includes/class-notifications.php';
require_once BWB_DIR . 'includes/class-privacy.php';

register_activation_hook( __FILE__, function ( $network_wide ) {
    if ( is_multisite() && $network_wide ) {
        wp_die( esc_html__( 'Activate AquaRoute separately on each site. Network activation is not supported.', 'bottled-water-booking' ) );
    }
    \BWB\Store::activate();
} );

add_action( 'plugins_loaded', function () {
    // Upgrades also run when an administrator updates an already-active plugin.
    if ( get_option( 'bwb_db_version' ) !== BWB_VERSION ) {
        \BWB\Store::activate();
    }
    new \BWB\Frontend();
    new \BWB\Admin();
    new \BWB\Notifications();
    new \BWB\Privacy();
} );

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
    if ( current_user_can( 'manage_options' ) ) {
        array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=bwb-settings' ) ) . '">' . esc_html__( 'Settings', 'bottled-water-booking' ) . '</a>' );
    }
    return $links;
} );

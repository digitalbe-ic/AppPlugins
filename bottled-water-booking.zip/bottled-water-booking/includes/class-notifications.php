<?php
namespace BWB;

defined( 'ABSPATH' ) || exit;

/** Plain-text, local WordPress mail. Delivery depends on the site's mail setup. */
class Notifications {
    public function __construct() {
        add_action( 'bwb_order_created', array( $this, 'created' ), 10, 2 );
        add_action( 'bwb_order_updated', array( $this, 'updated' ), 10, 2 );
    }

    public function created( $order, $token ) {
        $settings = Store::settings();
        $subject = sprintf( '[%s] New water order %s', $settings['business_name'], $order['reference'] );
        $summary = $this->summary( $order );
        $supplier = $settings['notification_email'];
        if ( is_email( $supplier ) ) {
            $body = $summary . "\n\nCustomer: " . $order['customer_name'] . "\nPhone: " . $order['phone'] . "\nEmail: " . $order['email'];
            $body .= "\nDelivery address: " . $order['address'] . "\nPostal code: " . $order['postcode'];
            $body .= "\nCustomer notes: " . $order['notes'];
            $body .= "\n\nManage order: " . admin_url( 'admin.php?page=bwb-orders&order_id=' . (int) $order['id'] );
            $this->send( $supplier, $subject, $body );
        }
        if ( ! empty( $settings['notify_customer'] ) && is_email( $order['email'] ) ) {
            $body = 'Hello ' . $order['customer_name'] . ",\n\nYour water order has been received and is awaiting supplier confirmation.\n\n" . $summary;
            $body .= "\n\nPayment: Cash on delivery.\n\nKeep these details private. Use the Track order form on our ordering page:";
            $body .= "\nOrder reference: " . $order['reference'] . "\nTracking key: " . $token;
            $body .= "\n\nContact the supplier to request changes or cancellation.\n\n" . $settings['business_name'];
            $this->send( $order['email'], sprintf( '[%s] Order received: %s', $settings['business_name'], $order['reference'] ), $body );
        }
    }

    public function updated( $order, $old ) {
        $settings = Store::settings();
        if ( empty( $settings['notify_customer'] ) || ! is_email( $order['email'] ) ) {
            return;
        }
        $changed = false;
        foreach ( array( 'status', 'payment_status', 'delivery_date', 'delivery_slot' ) as $field ) {
            if ( $order[ $field ] !== $old[ $field ] ) {
                $changed = true;
            }
        }
        if ( ! $changed ) {
            return;
        }
        $body = 'Hello ' . $order['customer_name'] . ",\n\nYour water order has been updated.\n\n" . $this->summary( $order );
        $body .= "\n\nUse your original private tracking key to check this order.\n\n" . $settings['business_name'];
        $this->send( $order['email'], sprintf( '[%s] Order update: %s', $settings['business_name'], $order['reference'] ), $body );
    }

    private function summary( $order ) {
        $statuses = Store::statuses();
        $lines = array(
            'Order: ' . $order['reference'],
            'Status: ' . ( isset( $statuses[ $order['status'] ] ) ? $statuses[ $order['status'] ] : $order['status'] ),
            'Delivery: ' . $order['delivery_date'] . ' / ' . $order['delivery_slot'],
            '',
        );
        foreach ( $order['items'] as $item ) {
            $lines[] = $item['name'] . ' × ' . $item['quantity'] . ' — ' . Store::money( $item['line_total_minor'], $order['currency'] );
        }
        $lines[] = 'Delivery fee: ' . Store::money( $order['delivery_fee_minor'], $order['currency'] );
        $lines[] = 'Total: ' . Store::money( $order['total_minor'], $order['currency'] );
        $lines[] = 'Payment status: ' . ucfirst( $order['payment_status'] );
        return implode( "\n", $lines );
    }

    private function send( $to, $subject, $body ) {
        // wp_mail errors must not turn a persisted booking into an apparent failure.
        wp_mail( $to, sanitize_text_field( $subject ), $body, array( 'Content-Type: text/plain; charset=UTF-8' ) );
    }
}

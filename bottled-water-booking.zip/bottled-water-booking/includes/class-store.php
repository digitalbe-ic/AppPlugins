<?php
/** Persistent orders, catalogue settings and business rules. */
namespace BWB;

defined( 'ABSPATH' ) || exit;

final class Store {

	public static function defaults(): array {
		return array(
			'business_name'       => 'AquaRoute Water Supply',
			'currency'            => 'USD',
			'delivery_fee_minor'  => 200,
			'lead_days'           => 1,
			'max_days'            => 30,
			'slots'               => array( 'Morning (9am–12pm)', 'Afternoon (12pm–4pm)', 'Evening (4pm–7pm)' ),
			'products'            => array(
				array( 'id' => '20l-bottle', 'name' => 'Everyday Water', 'size' => '20 litre bottle', 'price_minor' => 500, 'active' => true ),
				array( 'id' => '10l-bottle', 'name' => 'Compact Water', 'size' => '10 litre bottle', 'price_minor' => 300, 'active' => true ),
				array( 'id' => '1l-case', 'name' => 'Water on the Go', 'size' => '12 × 1 litre bottles', 'price_minor' => 800, 'active' => true ),
			),
			'notification_email'  => get_option( 'admin_email', '' ),
			'notify_customer'     => true,
		);
	}

	public static function settings(): array {
		$saved = get_option( 'bwb_settings', array() );
		return array_merge( self::defaults(), is_array( $saved ) ? $saved : array() );
	}

	/** Reject the whole change on invalid data to preserve a working catalogue. */
	public static function sanitize_settings( $input ): array {
		$previous = self::settings();
		if ( ! is_array( $input ) ) {
			add_settings_error( 'bwb_settings', 'invalid_settings', 'Settings must be submitted as a form.' );
			return $previous;
		}
		$errors = array();
		$result = $previous;
		$name = self::text_value( $input['business_name'] ?? '', 120 );
		if ( null === $name || '' === $name ) {
			$errors[] = 'Enter a business name of up to 120 characters.';
		} else {
			$result['business_name'] = $name;
		}
		$currency = is_string( $input['currency'] ?? null ) ? strtoupper( trim( $input['currency'] ) ) : '';
		if ( ! preg_match( '/^[A-Z]{3}$/D', $currency ) ) {
			$errors[] = 'Currency must be a three-letter code such as USD, EUR or INR. Prices use two decimal places.';
		} else {
			$result['currency'] = $currency;
		}
		foreach ( array( 'delivery_fee_minor' => array( 0, 100000000 ), 'lead_days' => array( 0, 30 ), 'max_days' => array( 1, 90 ) ) as $key => $range ) {
			$value = self::integer_value( $input[ $key ] ?? null, $range[0], $range[1] );
			if ( null === $value ) {
				$errors[] = sprintf( '%s must be a whole number between %d and %d.', str_replace( '_', ' ', ucfirst( $key ) ), $range[0], $range[1] );
			} else {
				$result[ $key ] = $value;
			}
		}
		if ( $result['max_days'] < $result['lead_days'] ) {
			$errors[] = 'The booking window must be at least as long as the delivery lead time.';
		}
		$slots = $input['slots'] ?? array();
		if ( is_string( $slots ) ) {
			$slots = preg_split( '/\r\n|\r|\n/', $slots );
		}
		$clean_slots = array();
		if ( ! is_array( $slots ) || count( $slots ) > 20 ) {
			$errors[] = 'Enter between one and twenty delivery slots.';
		} else {
			foreach ( $slots as $slot ) {
				$value = self::text_value( $slot, 120 );
				if ( null === $value ) {
					$errors[] = 'Delivery slot names must be text of up to 120 characters.';
					break;
				}
				if ( '' !== $value ) {
					$clean_slots[] = $value;
				}
			}
			$clean_slots = array_values( array_unique( $clean_slots ) );
			if ( ! $clean_slots ) {
				$errors[] = 'At least one delivery slot is required.';
			}
		}
		$result['slots'] = $clean_slots;
		$products = $input['products'] ?? array();
		$clean_products = array();
		$ids = array();
		if ( ! is_array( $products ) || count( $products ) > 10 ) {
			$errors[] = 'The catalogue supports up to ten products.';
		} else {
			foreach ( $products as $product ) {
				if ( ! is_array( $product ) ) {
					$errors[] = 'Invalid product row.';
					continue;
				}
				$id = self::text_value( $product['id'] ?? '', 40 );
				$product_name = self::text_value( $product['name'] ?? '', 120 );
				$size = self::text_value( $product['size'] ?? '', 80 );
				if ( '' === $id && '' === $product_name && '' === $size ) {
					continue;
				}
				$price = self::integer_value( $product['price_minor'] ?? null, 0, 100000000 );
				if ( null === $id || ! preg_match( '/^[a-z0-9][a-z0-9_-]{0,39}$/D', $id ) || isset( $ids[ $id ] ) || null === $product_name || '' === $product_name || null === $size || null === $price ) {
					$errors[] = 'Each product needs a unique lowercase ID, a name, a size of up to 80 characters, and a nonnegative whole-number price in minor units.';
					continue;
				}
				$ids[ $id ] = true;
				$clean_products[] = array( 'id' => $id, 'name' => $product_name, 'size' => $size, 'price_minor' => $price, 'active' => ! empty( $product['active'] ) );
			}
		}
		if ( ! array_filter( $clean_products, static function ( $product ) { return $product['active']; } ) ) {
			$errors[] = 'At least one active product is required.';
		}
		$result['products'] = $clean_products;
		$email = $input['notification_email'] ?? '';
		if ( ! is_string( $email ) || strlen( $email ) > 190 || ( '' !== trim( $email ) && ! is_email( trim( $email ) ) ) ) {
			$errors[] = 'Enter a valid supplier notification email or leave it blank to disable supplier emails.';
		} else {
			$result['notification_email'] = sanitize_email( trim( $email ) );
		}
		$result['notify_customer'] = ! empty( $input['notify_customer'] );
		if ( $errors ) {
			foreach ( array_unique( $errors ) as $index => $message ) {
				add_settings_error( 'bwb_settings', 'bwb_invalid_' . $index, $message );
			}
			return $previous;
		}
		return $result;
	}

	public static function products(): array {
		return array_values( array_filter( self::settings()['products'], static function ( $product ) { return ! empty( $product['active'] ); } ) );
	}

	public static function statuses(): array {
		return array( 'pending' => 'Pending', 'confirmed' => 'Confirmed', 'out_for_delivery' => 'Out for delivery', 'delivered' => 'Delivered', 'cancelled' => 'Cancelled' );
	}

	public static function money( $minor, $currency = null ): string {
		return ( $currency ?? self::settings()['currency'] ) . ' ' . number_format( (int) $minor / 100, 2, '.', ',' );
	}

	public static function date_bounds(): array {
		$settings = self::settings();
		$today = new \DateTimeImmutable( 'today', wp_timezone() );
		return array( 'min' => $today->modify( '+' . (int) $settings['lead_days'] . ' days' )->format( 'Y-m-d' ), 'max' => $today->modify( '+' . (int) $settings['max_days'] . ' days' )->format( 'Y-m-d' ) );
	}

	public static function activate() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$table = self::table();
		$charset = $wpdb->get_charset_collate();
		$sql = "CREATE TABLE $table (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			reference varchar(32) NOT NULL,
			access_token_hash char(64) NOT NULL,
			request_key char(64) NOT NULL,
			customer_id bigint(20) unsigned NOT NULL DEFAULT 0,
			customer_name varchar(120) NOT NULL,
			email varchar(190) NOT NULL,
			phone varchar(40) NOT NULL,
			address text NOT NULL,
			postcode varchar(30) NOT NULL DEFAULT '',
			delivery_date date NOT NULL,
			delivery_slot varchar(120) NOT NULL,
			notes text NOT NULL,
			items longtext NOT NULL,
			subtotal_minor bigint(20) unsigned NOT NULL,
			delivery_fee_minor bigint(20) unsigned NOT NULL,
			total_minor bigint(20) unsigned NOT NULL,
			currency char(3) NOT NULL,
			status varchar(24) NOT NULL DEFAULT 'pending',
			payment_status varchar(16) NOT NULL DEFAULT 'unpaid',
			driver_name varchar(120) NOT NULL DEFAULT '',
			delivery_notes text NOT NULL,
			created_at datetime NOT NULL,
			updated_at datetime NOT NULL,
			version bigint(20) unsigned NOT NULL DEFAULT 1,
			PRIMARY KEY  (id),
			UNIQUE KEY reference (reference),
			UNIQUE KEY request_key (request_key),
			KEY delivery_date (delivery_date),
			KEY status (status),
			KEY customer_email (email)
		) $charset;";
		dbDelta( $sql );
		add_role( 'bwb_supplier', 'Water Supplier', array( 'read' => true, 'bwb_manage_orders' => true ) );
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			$admin->add_cap( 'bwb_manage_orders' );
		}
		$supplier = get_role( 'bwb_supplier' );
		if ( $supplier ) {
			$supplier->add_cap( 'bwb_manage_orders' );
		}
		add_option( 'bwb_settings', self::defaults() );
		update_option( 'bwb_db_version', defined( 'BWB_VERSION' ) ? BWB_VERSION : '1.0.0' );
	}

	public static function create_order( array $input ) {
		global $wpdb;
		if ( ! empty( $input['website'] ) ) {
			return self::error( 'invalid_order', 'Your order could not be submitted. Please reload and try again.' );
		}
		$request_key = $input['request_key'] ?? '';
		if ( ! is_string( $request_key ) || ! preg_match( '/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/iD', $request_key ) ) {
			return self::error( 'invalid_request_key', 'Please reload the order form and try again.' );
		}
		$request_hash = hash( 'sha256', strtolower( $request_key ) );
		if ( $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::table() . ' WHERE request_key = %s', $request_hash ) ) ) {
			return self::error( 'duplicate_order', 'This order was already submitted. Please use the confirmation you received or contact the supplier before placing it again.', 409 );
		}
		$order = array();
		foreach ( array( 'customer_name' => 120, 'email' => 190, 'phone' => 40, 'address' => 1000, 'postcode' => 30, 'notes' => 2000 ) as $field => $limit ) {
			$value = self::text_value( $input[ $field ] ?? '', $limit, in_array( $field, array( 'address', 'notes' ), true ) );
			if ( null === $value ) {
				return self::error( 'invalid_' . $field, sprintf( '%s must be text of up to %d characters.', ucfirst( str_replace( '_', ' ', $field ) ), $limit ) );
			}
			$order[ $field ] = $value;
		}
		if ( strlen( $order['customer_name'] ) < 2 || strlen( $order['address'] ) < 5 || ! is_email( $order['email'] ) ) {
			return self::error( 'missing_customer_details', 'Please enter your full name, valid email address and complete delivery address.' );
		}
		if ( ! preg_match( '/^[0-9+().\s-]{7,40}$/D', $order['phone'] ) || strlen( preg_replace( '/\D/', '', $order['phone'] ) ) < 7 ) {
			return self::error( 'invalid_phone', 'Please enter a valid contact phone number.' );
		}
		$order['email'] = sanitize_email( $order['email'] );
		$date = $input['delivery_date'] ?? '';
		$slot = $input['delivery_slot'] ?? '';
		if ( ! self::valid_delivery_date( $date ) ) {
			return self::error( 'invalid_delivery_date', 'Choose an available delivery date within the booking window.' );
		}
		$settings = self::settings();
		if ( ! is_string( $slot ) || ! in_array( $slot, $settings['slots'], true ) ) {
			return self::error( 'invalid_delivery_slot', 'Please choose an available delivery slot.' );
		}
		$items = $input['items'] ?? null;
		if ( ! is_array( $items ) || ! $items || count( $items ) > 10 ) {
			return self::error( 'invalid_items', 'Choose at least one product, with a maximum of ten different products.' );
		}
		$catalogue = array_column( self::products(), null, 'id' );
		$lines = array();
		$seen = array();
		$subtotal = 0;
		foreach ( $items as $item ) {
			if ( ! is_array( $item ) || ! is_string( $item['product_id'] ?? null ) || ! isset( $catalogue[ $item['product_id'] ] ) ) {
				return self::error( 'invalid_product', 'A selected product is unavailable. Please reload the catalogue.' );
			}
			$id = $item['product_id'];
			$quantity = self::integer_value( $item['quantity'] ?? null, 1, 99 );
			if ( isset( $seen[ $id ] ) || null === $quantity ) {
				return self::error( 'invalid_quantity', 'Choose a whole-number quantity from 1 to 99 for each product, with no duplicate products.' );
			}
			$seen[ $id ] = true;
			$product = $catalogue[ $id ];
			$line_total = (int) $product['price_minor'] * $quantity;
			$lines[] = array( 'product_id' => $id, 'name' => $product['name'], 'size' => $product['size'], 'quantity' => $quantity, 'unit_price_minor' => (int) $product['price_minor'], 'line_total_minor' => $line_total );
			$subtotal += $line_total;
		}
		try {
			$token = bin2hex( random_bytes( 32 ) );
			$reference = 'BWB-' . wp_date( 'ymd' ) . '-' . strtoupper( bin2hex( random_bytes( 5 ) ) );
		} catch ( \Exception $exception ) {
			return self::error( 'unavailable', 'Secure ordering is temporarily unavailable. Please try again later.', 503 );
		}
		$now = current_time( 'mysql' );
		$order = array_merge( $order, array(
			'reference' => $reference,
			'access_token_hash' => hash( 'sha256', $token ),
			'request_key' => $request_hash,
			'customer_id' => get_current_user_id(),
			'delivery_date' => $date,
			'delivery_slot' => $slot,
			'items' => wp_json_encode( $lines ),
			'subtotal_minor' => $subtotal,
			'delivery_fee_minor' => (int) $settings['delivery_fee_minor'],
			'total_minor' => $subtotal + (int) $settings['delivery_fee_minor'],
			'currency' => $settings['currency'],
			'status' => 'pending',
			'payment_status' => 'unpaid',
			'driver_name' => '',
			'delivery_notes' => '',
			'created_at' => $now,
			'updated_at' => $now,
			'version' => 1,
		) );
		$inserted = $wpdb->insert( self::table(), $order );
		if ( false === $inserted ) {
			if ( $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . self::table() . ' WHERE request_key = %s', $request_hash ) ) ) {
				return self::error( 'duplicate_order', 'This order was already submitted. Please contact the supplier before placing it again.', 409 );
			}
			return self::error( 'order_not_saved', 'Your order could not be saved. Please try again later.', 500 );
		}
		$order['id'] = (int) $wpdb->insert_id;
		$order['items'] = $lines;
		do_action( 'bwb_order_created', $order, $token );
		return array( 'order' => $order, 'token' => $token, 'duplicate' => false );
	}

	public static function track_order( string $reference, string $token ) {
		global $wpdb;
		$reference = strtoupper( trim( $reference ) );
		if ( ! preg_match( '/^BWB-[0-9]{6}-[A-F0-9]{10}$/D', $reference ) || ! preg_match( '/^[a-f0-9]{64}$/D', $token ) ) {
			return self::error( 'order_not_found', 'We could not find an order with those tracking details.', 404 );
		}
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE reference = %s', $reference ), ARRAY_A );
		if ( ! $row || ! hash_equals( $row['access_token_hash'], hash( 'sha256', $token ) ) ) {
			return self::error( 'order_not_found', 'We could not find an order with those tracking details.', 404 );
		}
		$row = self::decode_order( $row );
		return array_intersect_key( $row, array_flip( array( 'reference', 'status', 'payment_status', 'delivery_date', 'delivery_slot', 'items', 'subtotal_minor', 'delivery_fee_minor', 'total_minor', 'currency', 'created_at', 'updated_at' ) ) );
	}

	public static function get_order( int $id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ), ARRAY_A );
		return $row ? self::decode_order( $row ) : null;
	}

	public static function list_orders( array $filters = array() ): array {
		global $wpdb;
		$where = '1=1';
		$values = array();
		if ( isset( $filters['status'] ) && is_string( $filters['status'] ) && '' !== $filters['status'] ) {
			if ( ! isset( self::statuses()[ $filters['status'] ] ) ) {
				return array( 'orders' => array(), 'total' => 0 );
			}
			$where .= ' AND status = %s';
			$values[] = $filters['status'];
		}
		if ( isset( $filters['delivery_date'] ) && is_string( $filters['delivery_date'] ) && '' !== $filters['delivery_date'] ) {
			if ( ! self::valid_calendar_date( $filters['delivery_date'] ) ) {
				return array( 'orders' => array(), 'total' => 0 );
			}
			$where .= ' AND delivery_date = %s';
			$values[] = $filters['delivery_date'];
		}
		if ( ! empty( $filters['search'] ) && is_string( $filters['search'] ) ) {
			$search = '%' . $wpdb->esc_like( substr( $filters['search'], 0, 190 ) ) . '%';
			$where .= ' AND (reference LIKE %s OR customer_name LIKE %s OR phone LIKE %s)';
			array_push( $values, $search, $search, $search );
		}
		$page = max( 1, (int) ( $filters['page'] ?? 1 ) );
		$limit = min( 100, max( 1, (int) ( $filters['per_page'] ?? 20 ) ) );
		$table = self::table();
		$count_sql = "SELECT COUNT(*) FROM $table WHERE $where";
		$total = (int) $wpdb->get_var( $values ? $wpdb->prepare( $count_sql, $values ) : $count_sql );
		$query_values = array_merge( $values, array( $limit, ( $page - 1 ) * $limit ) );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $table WHERE $where ORDER BY id DESC LIMIT %d OFFSET %d", $query_values ), ARRAY_A );
		return array( 'orders' => array_map( array( __CLASS__, 'decode_order' ), $rows ?: array() ), 'total' => $total );
	}

	public static function stats(): array {
		global $wpdb;
		$table = self::table();
		$stats = array_fill_keys( array_merge( array( 'total', 'today', 'unpaid', 'revenue_minor' ), array_keys( self::statuses() ) ), 0 );
		$grouped = $wpdb->get_results( "SELECT status, COUNT(*) AS count FROM $table GROUP BY status", ARRAY_A );
		foreach ( $grouped ?: array() as $group ) {
			$stats['total'] += (int) $group['count'];
			if ( isset( $stats[ $group['status'] ] ) ) {
				$stats[ $group['status'] ] = (int) $group['count'];
			}
		}
		$stats['today'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $table WHERE delivery_date = %s AND status != 'cancelled'", wp_date( 'Y-m-d' ) ) );
		$stats['unpaid'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table WHERE payment_status = 'unpaid' AND status != 'cancelled'" );
		$stats['currency'] = self::settings()['currency'];
		$stats['revenue_minor'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(total_minor),0) FROM $table WHERE status = 'delivered' AND payment_status = 'paid' AND currency = %s", $stats['currency'] ) );
		return $stats;
	}

	public static function update_order( int $id, array $changes, int $version ) {
		global $wpdb;
		if ( ! current_user_can( 'bwb_manage_orders' ) ) {
			return self::error( 'forbidden', 'You do not have permission to manage orders.', 403 );
		}
		$old = self::get_order( $id );
		if ( ! $old ) {
			return self::error( 'order_not_found', 'The order could not be found.', 404 );
		}
		if ( $version < 1 || $version !== $old['version'] ) {
			return self::error( 'order_changed', 'This order was changed by someone else. Reload the order before saving.', 409 );
		}
		$allowed = array(
			'pending' => array( 'pending', 'confirmed', 'cancelled' ),
			'confirmed' => array( 'confirmed', 'out_for_delivery', 'cancelled' ),
			'out_for_delivery' => array( 'out_for_delivery', 'delivered', 'confirmed', 'cancelled' ),
			'delivered' => array( 'delivered' ),
			'cancelled' => array( 'cancelled' ),
		);
		$status = $changes['status'] ?? $old['status'];
		if ( ! is_string( $status ) || ! in_array( $status, $allowed[ $old['status'] ] ?? array(), true ) ) {
			return self::error( 'invalid_status_transition', 'That status change is unavailable. Confirm pending orders before dispatching, then mark dispatched orders as delivered.' );
		}
		$payment = $changes['payment_status'] ?? $old['payment_status'];
		if ( ! in_array( $payment, array( 'unpaid', 'paid' ), true ) ) {
			return self::error( 'invalid_payment_status', 'Choose a valid payment status.' );
		}
		$data = array( 'status' => $status, 'payment_status' => $payment );
		foreach ( array( 'driver_name' => 120, 'delivery_notes' => 2000 ) as $field => $limit ) {
			if ( array_key_exists( $field, $changes ) ) {
				$value = self::text_value( $changes[ $field ], $limit, 'delivery_notes' === $field );
				if ( null === $value ) {
					return self::error( 'invalid_' . $field, sprintf( '%s must be text of up to %d characters.', ucfirst( str_replace( '_', ' ', $field ) ), $limit ) );
				}
				$data[ $field ] = $value;
			}
		}
		$date = $changes['delivery_date'] ?? $old['delivery_date'];
		$slot = $changes['delivery_slot'] ?? $old['delivery_slot'];
		if ( $date !== $old['delivery_date'] || $slot !== $old['delivery_slot'] ) {
			if ( in_array( $old['status'], array( 'delivered', 'cancelled' ), true ) || in_array( $status, array( 'delivered', 'cancelled' ), true ) ) {
				return self::error( 'terminal_order', 'Delivered or cancelled orders cannot be rescheduled.' );
			}
			if ( ! self::valid_delivery_date( $date ) || ! is_string( $slot ) || ! in_array( $slot, self::settings()['slots'], true ) ) {
				return self::error( 'invalid_delivery_schedule', 'Choose an available delivery date and slot.' );
			}
			$data['delivery_date'] = $date;
			$data['delivery_slot'] = $slot;
		}
		$data['version'] = $version + 1;
		$data['updated_at'] = current_time( 'mysql' );
		$changed = $wpdb->update( self::table(), $data, array( 'id' => $id, 'version' => $version ) );
		if ( false === $changed ) {
			return self::error( 'update_failed', 'The order could not be updated. Please try again.', 500 );
		}
		if ( 0 === $changed ) {
			return self::error( 'order_changed', 'This order was changed by someone else. Reload the order before saving.', 409 );
		}
		$updated = self::get_order( $id );
		do_action( 'bwb_order_updated', $updated, $old );
		return $updated;
	}

	private static function table(): string {
		global $wpdb;
		return $wpdb->prefix . 'bwb_orders';
	}

	private static function decode_order( array $row ): array {
		$row['items'] = json_decode( $row['items'], true ) ?: array();
		foreach ( array( 'id', 'customer_id', 'subtotal_minor', 'delivery_fee_minor', 'total_minor', 'version' ) as $key ) {
			$row[ $key ] = (int) $row[ $key ];
		}
		return $row;
	}

	private static function text_value( $value, int $limit, bool $multiline = false ) {
		if ( ! is_string( $value ) || strlen( $value ) > $limit ) {
			return null;
		}
		return trim( $multiline ? sanitize_textarea_field( $value ) : sanitize_text_field( $value ) );
	}

	private static function integer_value( $value, int $minimum, int $maximum ) {
		if ( ! is_int( $value ) && ! ( is_string( $value ) && preg_match( '/^(0|[1-9][0-9]*)$/D', $value ) ) ) {
			return null;
		}
		if ( $value < $minimum || $value > $maximum ) {
			return null;
		}
		return (int) $value;
	}

	private static function valid_calendar_date( $value ): bool {
		if ( ! is_string( $value ) || ! preg_match( '/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/D', $value ) ) {
			return false;
		}
		$parts = array_map( 'intval', explode( '-', $value ) );
		return checkdate( $parts[1], $parts[2], $parts[0] );
	}

	private static function valid_delivery_date( $value ): bool {
		if ( ! self::valid_calendar_date( $value ) ) {
			return false;
		}
		$bounds = self::date_bounds();
		return $value >= $bounds['min'] && $value <= $bounds['max'];
	}

	private static function error( string $code, string $message, int $status = 400 ): \WP_Error {
		return new \WP_Error( $code, $message, array( 'status' => $status ) );
	}
}

<?php
/** Supplier order management and administrator settings. */
namespace BWB;

defined( 'ABSPATH' ) || exit;

class Admin {

	public function __construct() {
		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'admin_post_bwb_update_order', array( $this, 'update_order' ) );
		add_action( 'admin_post_bwb_export', array( $this, 'export_orders' ) );
	}

	public function menu() {
		add_menu_page( __( 'Water Supply', 'bottled-water-booking' ), __( 'Water Supply', 'bottled-water-booking' ), 'bwb_manage_orders', 'bwb-orders', array( $this, 'orders_page' ), 'dashicons-store', 26 );
		add_submenu_page( 'bwb-orders', __( 'Orders & delivery', 'bottled-water-booking' ), __( 'Orders & delivery', 'bottled-water-booking' ), 'bwb_manage_orders', 'bwb-orders', array( $this, 'orders_page' ) );
		add_submenu_page( 'bwb-orders', __( 'Water Supply Settings', 'bottled-water-booking' ), __( 'Settings', 'bottled-water-booking' ), 'manage_options', 'bwb-settings', array( $this, 'settings_page' ) );
	}

	public function enqueue( $hook ) {
		if ( false !== strpos( $hook, 'bwb-orders' ) || false !== strpos( $hook, 'bwb-settings' ) ) {
			wp_enqueue_style( 'bwb-admin', BWB_URL . 'assets/admin.css', array(), BWB_VERSION );
		}
	}

	public function register_settings() {
		register_setting( 'bwb_settings_group', 'bwb_settings', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize_settings' ), 'default' => Store::defaults() ) );
	}

	public function sanitize_settings( $input ) {
		if ( ! is_array( $input ) ) {
			return Store::sanitize_settings( $input );
		}
		if ( isset( $input['slots_text'] ) && is_string( $input['slots_text'] ) ) {
			$input['slots'] = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n/', $input['slots_text'] ) ), 'strlen' ) );
		}
		unset( $input['slots_text'] );
		return Store::sanitize_settings( $input );
	}

	private function require_supplier() {
		if ( ! current_user_can( 'bwb_manage_orders' ) ) {
			wp_die( esc_html__( 'You do not have permission to manage water orders.', 'bottled-water-booking' ), '', array( 'response' => 403 ) );
		}
	}

	private function scalar( $source, $key, $default = '' ) {
		return isset( $source[ $key ] ) && is_scalar( $source[ $key ] ) ? (string) wp_unslash( $source[ $key ] ) : $default;
	}

	private function filters( $source ) {
		$status = sanitize_key( $this->scalar( $source, 'status' ) );
		$date   = sanitize_text_field( $this->scalar( $source, 'delivery_date' ) );
		return array(
			'status'        => isset( Store::statuses()[ $status ] ) ? $status : '',
			'delivery_date' => preg_match( '/^\d{4}-\d{2}-\d{2}$/D', $date ) ? $date : '',
			'search'        => substr( sanitize_text_field( $this->scalar( $source, 's' ) ), 0, 150 ),
			'page'          => max( 1, absint( $this->scalar( $source, 'paged', '1' ) ) ),
			'per_page'      => 20,
		);
	}

	private function status_badge( $status ) {
		$statuses = Store::statuses();
		return '<span class="bwb-badge bwb-badge--' . esc_attr( sanitize_html_class( $status ) ) . '">' . esc_html( isset( $statuses[ $status ] ) ? $statuses[ $status ] : $status ) . '</span>';
	}

	private function header( $title, $subtitle ) {
		?>
		<div class="bwb-admin-header">
			<div class="bwb-brand"><span class="dashicons dashicons-admin-site-alt3" aria-hidden="true"></span> AQUAROUTE <span class="bwb-brand-label"><?php esc_html_e( 'SUPPLIER WORKSPACE', 'bottled-water-booking' ); ?></span></div>
			<h1><?php echo esc_html( $title ); ?></h1>
			<p><?php echo esc_html( $subtitle ); ?></p>
		</div>
		<?php
	}

	private function notices() {
		$notice = sanitize_key( $this->scalar( $_GET, 'bwb_notice' ) );
		if ( 'saved' === $notice ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . esc_html__( 'Order updated.', 'bottled-water-booking' ) . '</p></div>';
		} elseif ( 'error' === $notice ) {
			$message = get_transient( 'bwb_admin_notice_' . get_current_user_id() );
			delete_transient( 'bwb_admin_notice_' . get_current_user_id() );
			echo '<div class="notice notice-error"><p>' . esc_html( is_string( $message ) ? $message : __( 'The order could not be updated. Reload the order and try again.', 'bottled-water-booking' ) ) . '</p></div>';
		}
	}

	public function orders_page() {
		$this->require_supplier();
		$id = absint( $this->scalar( $_GET, 'order_id' ) );
		if ( $id ) {
			$this->order_detail( $id );
			return;
		}
		$filters = $this->filters( $_GET );
		$result  = Store::list_orders( $filters );
		$stats   = Store::stats();
		?>
		<div class="wrap bwb-admin">
			<?php $this->header( __( 'Orders & delivery', 'bottled-water-booking' ), __( 'A clear view of every order, from booking to doorstep.', 'bottled-water-booking' ) ); ?>
			<?php $this->notices(); ?>
			<div class="bwb-stat-grid">
				<?php
				$cards = array(
					array( 'pending', __( 'Awaiting confirmation', 'bottled-water-booking' ), 'clock', 'amber' ),
					array( 'today', __( 'Scheduled today', 'bottled-water-booking' ), 'calendar-alt', 'blue' ),
					array( 'out_for_delivery', __( 'Out for delivery', 'bottled-water-booking' ), 'location-alt', 'teal' ),
					array( 'delivered', __( 'Delivered orders', 'bottled-water-booking' ), 'yes-alt', 'green' ),
				);
				foreach ( $cards as $card ) :
					?>
					<div class="bwb-stat"><span class="bwb-stat-icon bwb-tone-<?php echo esc_attr( $card[3] ); ?> dashicons dashicons-<?php echo esc_attr( $card[2] ); ?>" aria-hidden="true"></span><div><span><?php echo esc_html( $card[1] ); ?></span><strong><?php echo esc_html( number_format_i18n( isset( $stats[ $card[0] ] ) ? $stats[ $card[0] ] : 0 ) ); ?></strong></div></div>
				<?php endforeach; ?>
			</div>
			<div class="bwb-toolbar-heading"><h2><?php esc_html_e( 'Order book', 'bottled-water-booking' ); ?> <span class="bwb-count"><?php echo esc_html( number_format_i18n( $result['total'] ) ); ?></span></h2>
				<form action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post">
					<input type="hidden" name="action" value="bwb_export">
					<input type="hidden" name="status" value="<?php echo esc_attr( $filters['status'] ); ?>"><input type="hidden" name="delivery_date" value="<?php echo esc_attr( $filters['delivery_date'] ); ?>"><input type="hidden" name="s" value="<?php echo esc_attr( $filters['search'] ); ?>">
					<?php wp_nonce_field( 'bwb_export' ); ?>
					<button class="button bwb-export" type="submit"><span class="dashicons dashicons-download" aria-hidden="true"></span> <?php esc_html_e( 'Export CSV', 'bottled-water-booking' ); ?></button>
				</form>
			</div>
			<div class="bwb-panel">
				<form method="get" class="bwb-filters">
					<input type="hidden" name="page" value="bwb-orders">
					<div class="bwb-filter-search"><label class="screen-reader-text" for="bwb-search"><?php esc_html_e( 'Search orders', 'bottled-water-booking' ); ?></label><input type="search" id="bwb-search" name="s" value="<?php echo esc_attr( $filters['search'] ); ?>" placeholder="<?php esc_attr_e( 'Reference, customer or phone', 'bottled-water-booking' ); ?>"></div>
					<div><label class="screen-reader-text" for="bwb-status-filter"><?php esc_html_e( 'Order status', 'bottled-water-booking' ); ?></label><select id="bwb-status-filter" name="status"><option value=""><?php esc_html_e( 'All statuses', 'bottled-water-booking' ); ?></option><?php foreach ( Store::statuses() as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $filters['status'], $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></div>
					<div><label class="screen-reader-text" for="bwb-date-filter"><?php esc_html_e( 'Delivery date', 'bottled-water-booking' ); ?></label><input id="bwb-date-filter" name="delivery_date" type="date" value="<?php echo esc_attr( $filters['delivery_date'] ); ?>" aria-label="<?php esc_attr_e( 'Delivery date', 'bottled-water-booking' ); ?>"></div>
					<button class="button button-primary" type="submit"><?php esc_html_e( 'Filter orders', 'bottled-water-booking' ); ?></button><a href="<?php echo esc_url( admin_url( 'admin.php?page=bwb-orders' ) ); ?>" class="bwb-reset"><?php esc_html_e( 'Reset', 'bottled-water-booking' ); ?></a>
				</form>
				<div class="bwb-table-scroll"><table class="widefat bwb-orders-table"><thead><tr><th><?php esc_html_e( 'Order', 'bottled-water-booking' ); ?></th><th><?php esc_html_e( 'Customer', 'bottled-water-booking' ); ?></th><th><?php esc_html_e( 'Delivery', 'bottled-water-booking' ); ?></th><th><?php esc_html_e( 'Status', 'bottled-water-booking' ); ?></th><th><?php esc_html_e( 'Total / payment', 'bottled-water-booking' ); ?></th><th><?php esc_html_e( 'Driver', 'bottled-water-booking' ); ?></th></tr></thead><tbody>
				<?php if ( empty( $result['orders'] ) ) : ?>
					<tr><td colspan="6"><div class="bwb-empty"><span class="dashicons dashicons-cart" aria-hidden="true"></span><h3><?php esc_html_e( 'No orders to show', 'bottled-water-booking' ); ?></h3><p><?php esc_html_e( 'New customer bookings will appear here. Try adjusting your filters.', 'bottled-water-booking' ); ?></p></div></td></tr>
				<?php endif; ?>
				<?php foreach ( $result['orders'] as $order ) : ?>
					<tr><td><a class="bwb-order-link" href="<?php echo esc_url( add_query_arg( array( 'page' => 'bwb-orders', 'order_id' => $order['id'] ), admin_url( 'admin.php' ) ) ); ?>"><?php echo esc_html( $order['reference'] ); ?><span class="dashicons dashicons-arrow-right-alt2" aria-hidden="true"></span></a><span class="bwb-secondary"><?php echo esc_html( substr( $order['created_at'], 0, 10 ) ); ?></span></td><td><strong><?php echo esc_html( $order['customer_name'] ); ?></strong><span class="bwb-secondary"><?php echo esc_html( $order['phone'] ); ?></span></td><td><strong><?php echo esc_html( $order['delivery_date'] ); ?></strong><span class="bwb-secondary"><?php echo esc_html( $order['delivery_slot'] ); ?></span></td><td><?php echo $this->status_badge( $order['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by status_badge. ?></td><td><strong><?php echo esc_html( Store::money( $order['total_minor'], $order['currency'] ) ); ?></strong><span class="bwb-secondary <?php echo 'paid' === $order['payment_status'] ? 'bwb-text-green' : ''; ?>"><?php echo 'paid' === $order['payment_status'] ? esc_html__( 'Paid', 'bottled-water-booking' ) : esc_html__( 'Unpaid · cash on delivery', 'bottled-water-booking' ); ?></span></td><td><?php echo esc_html( $order['driver_name'] ? $order['driver_name'] : __( 'Unassigned', 'bottled-water-booking' ) ); ?></td></tr>
				<?php endforeach; ?>
				</tbody></table></div>
				<?php $this->pagination( $result['total'], $filters ); ?>
			</div>
			<p class="bwb-footer-note"><?php esc_html_e( 'Delivery dates and times use your WordPress site timezone.', 'bottled-water-booking' ); ?> <strong><?php echo esc_html( wp_timezone_string() ); ?></strong></p>
		</div>
		<?php
	}

	private function pagination( $total, $filters ) {
		$pages = (int) ceil( $total / $filters['per_page'] );
		?>
		<div class="bwb-pagination"><span><?php echo esc_html( sprintf( __( '%s orders', 'bottled-water-booking' ), number_format_i18n( $total ) ) ); ?></span>
		<?php
		if ( $pages > 1 ) {
			$base = add_query_arg( array( 'page' => 'bwb-orders', 's' => $filters['search'], 'status' => $filters['status'], 'delivery_date' => $filters['delivery_date'], 'paged' => '%#%' ), admin_url( 'admin.php' ) );
			echo wp_kses_post( paginate_links( array( 'base' => $base, 'format' => '', 'current' => min( $pages, $filters['page'] ), 'total' => $pages, 'prev_text' => __( 'Previous', 'bottled-water-booking' ), 'next_text' => __( 'Next', 'bottled-water-booking' ) ) ) );
		}
		echo '</div>';
	}

	private function order_detail( $id ) {
		$order = Store::get_order( $id );
		if ( ! $order ) {
			wp_die( esc_html__( 'Order not found.', 'bottled-water-booking' ), '', array( 'response' => 404 ) );
		}
		$terminal = in_array( $order['status'], array( 'delivered', 'cancelled' ), true );
		$transitions = array( 'pending' => array( 'pending', 'confirmed', 'cancelled' ), 'confirmed' => array( 'confirmed', 'out_for_delivery', 'cancelled' ), 'out_for_delivery' => array( 'out_for_delivery', 'delivered', 'confirmed', 'cancelled' ), 'delivered' => array( 'delivered' ), 'cancelled' => array( 'cancelled' ) );
		$settings = Store::settings();
		$bounds = Store::date_bounds();
		?>
		<div class="wrap bwb-admin">
			<a class="bwb-back" href="<?php echo esc_url( admin_url( 'admin.php?page=bwb-orders' ) ); ?>">← <?php esc_html_e( 'All orders', 'bottled-water-booking' ); ?></a>
			<?php $this->header( $order['reference'], __( 'Order details, delivery assignment and payment record.', 'bottled-water-booking' ) ); ?>
			<?php $this->notices(); ?>
			<div class="bwb-detail-grid">
				<div>
					<section class="bwb-panel bwb-detail-panel"><div class="bwb-section-heading"><h2><?php esc_html_e( 'Order summary', 'bottled-water-booking' ); ?></h2><?php echo $this->status_badge( $order['status'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
						<div class="bwb-table-scroll"><table class="widefat bwb-items-table"><thead><tr><th><?php esc_html_e( 'Product', 'bottled-water-booking' ); ?></th><th><?php esc_html_e( 'Quantity', 'bottled-water-booking' ); ?></th><th><?php esc_html_e( 'Amount', 'bottled-water-booking' ); ?></th></tr></thead><tbody><?php foreach ( $order['items'] as $item ) : ?><tr><td><strong><?php echo esc_html( $item['name'] ); ?></strong><span class="bwb-secondary"><?php echo esc_html( Store::money( $item['unit_price_minor'], $order['currency'] ) ); ?> <?php esc_html_e( 'each', 'bottled-water-booking' ); ?></span></td><td><?php echo esc_html( $item['quantity'] ); ?></td><td><?php echo esc_html( Store::money( $item['line_total_minor'], $order['currency'] ) ); ?></td></tr><?php endforeach; ?></tbody></table></div>
						<dl class="bwb-totals"><div><dt><?php esc_html_e( 'Subtotal', 'bottled-water-booking' ); ?></dt><dd><?php echo esc_html( Store::money( $order['subtotal_minor'], $order['currency'] ) ); ?></dd></div><div><dt><?php esc_html_e( 'Delivery', 'bottled-water-booking' ); ?></dt><dd><?php echo esc_html( Store::money( $order['delivery_fee_minor'], $order['currency'] ) ); ?></dd></div><div class="bwb-total"><dt><?php esc_html_e( 'Total', 'bottled-water-booking' ); ?></dt><dd><?php echo esc_html( Store::money( $order['total_minor'], $order['currency'] ) ); ?></dd></div></dl>
					</section>
					<section class="bwb-panel bwb-detail-panel"><h2><?php esc_html_e( 'Customer & destination', 'bottled-water-booking' ); ?></h2><dl class="bwb-information"><div><dt><?php esc_html_e( 'Customer', 'bottled-water-booking' ); ?></dt><dd><?php echo esc_html( $order['customer_name'] ); ?></dd></div><div><dt><?php esc_html_e( 'Email', 'bottled-water-booking' ); ?></dt><dd><a href="<?php echo esc_url( 'mailto:' . $order['email'] ); ?>"><?php echo esc_html( $order['email'] ); ?></a></dd></div><div><dt><?php esc_html_e( 'Phone', 'bottled-water-booking' ); ?></dt><dd><?php echo esc_html( $order['phone'] ); ?></dd></div><div><dt><?php esc_html_e( 'Address', 'bottled-water-booking' ); ?></dt><dd><?php echo nl2br( esc_html( $order['address'] ) ); ?><br><?php echo esc_html( $order['postcode'] ); ?></dd></div><div><dt><?php esc_html_e( 'Scheduled delivery', 'bottled-water-booking' ); ?></dt><dd><?php echo esc_html( $order['delivery_date'] . ' · ' . $order['delivery_slot'] ); ?></dd></div><div><dt><?php esc_html_e( 'Customer note', 'bottled-water-booking' ); ?></dt><dd><?php echo $order['notes'] ? nl2br( esc_html( $order['notes'] ) ) : '—'; ?></dd></div></dl></section>
					<p class="bwb-footer-note"><?php esc_html_e( 'Created', 'bottled-water-booking' ); ?> <?php echo esc_html( $order['created_at'] ); ?> · <?php esc_html_e( 'Updated', 'bottled-water-booking' ); ?> <?php echo esc_html( $order['updated_at'] ); ?> · <?php echo esc_html( wp_timezone_string() ); ?></p>
				</div>
				<aside><section class="bwb-panel bwb-detail-panel"><h2><?php esc_html_e( 'Manage delivery', 'bottled-water-booking' ); ?></h2>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="bwb-management-form">
						<input type="hidden" name="action" value="bwb_update_order"><input type="hidden" name="order_id" value="<?php echo esc_attr( $id ); ?>"><input type="hidden" name="version" value="<?php echo esc_attr( $order['version'] ); ?>"><?php wp_nonce_field( 'bwb_update_order_' . $id ); ?>
						<label for="bwb-order-status"><?php esc_html_e( 'Order status', 'bottled-water-booking' ); ?></label><select name="status" id="bwb-order-status"><?php foreach ( Store::statuses() as $value => $label ) : if ( ! in_array( $value, $transitions[ $order['status'] ], true ) ) { continue; } ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $order['status'], $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select>
						<label for="bwb-payment"><?php esc_html_e( 'Payment', 'bottled-water-booking' ); ?></label><select name="payment_status" id="bwb-payment"><option value="unpaid" <?php selected( $order['payment_status'], 'unpaid' ); ?>><?php esc_html_e( 'Unpaid — collect on delivery', 'bottled-water-booking' ); ?></option><option value="paid" <?php selected( $order['payment_status'], 'paid' ); ?>><?php esc_html_e( 'Paid', 'bottled-water-booking' ); ?></option></select>
						<label for="bwb-driver"><?php esc_html_e( 'Assigned driver', 'bottled-water-booking' ); ?></label><input name="driver_name" id="bwb-driver" type="text" maxlength="120" value="<?php echo esc_attr( $order['driver_name'] ); ?>" placeholder="<?php esc_attr_e( 'Driver name', 'bottled-water-booking' ); ?>">
						<label for="bwb-delivery-notes"><?php esc_html_e( 'Internal delivery notes', 'bottled-water-booking' ); ?></label><textarea name="delivery_notes" id="bwb-delivery-notes" rows="4" maxlength="2000"><?php echo esc_textarea( $order['delivery_notes'] ); ?></textarea><p class="description"><?php esc_html_e( 'Visible to suppliers only.', 'bottled-water-booking' ); ?></p>
						<?php if ( ! $terminal ) : ?>
							<details class="bwb-reschedule"><summary><?php esc_html_e( 'Reschedule delivery', 'bottled-water-booking' ); ?></summary><p><label><input type="checkbox" name="reschedule" value="1"> <?php esc_html_e( 'Apply a new date and time slot', 'bottled-water-booking' ); ?></label></p><label for="bwb-new-date"><?php esc_html_e( 'New delivery date', 'bottled-water-booking' ); ?></label><input id="bwb-new-date" type="date" name="delivery_date" min="<?php echo esc_attr( $bounds['min'] ); ?>" max="<?php echo esc_attr( $bounds['max'] ); ?>"><label for="bwb-new-slot"><?php esc_html_e( 'New delivery slot', 'bottled-water-booking' ); ?></label><select id="bwb-new-slot" name="delivery_slot"><option value=""><?php esc_html_e( 'Select a slot', 'bottled-water-booking' ); ?></option><?php foreach ( $settings['slots'] as $slot ) : ?><option value="<?php echo esc_attr( $slot ); ?>"><?php echo esc_html( $slot ); ?></option><?php endforeach; ?></select></details>
						<?php else : ?><p class="bwb-inline-note"><?php esc_html_e( 'This order is closed. Payment, driver and internal notes can still be updated.', 'bottled-water-booking' ); ?></p><?php endif; ?>
						<button class="button button-primary button-large bwb-save-order" type="submit"><?php esc_html_e( 'Save order', 'bottled-water-booking' ); ?></button>
					</form>
				</section></aside>
			</div>
		</div>
		<?php
	}

	public function update_order() {
		$this->require_supplier();
		$id = absint( $this->scalar( $_POST, 'order_id' ) );
		check_admin_referer( 'bwb_update_order_' . $id );
		$changes = array(
			'status'         => sanitize_key( $this->scalar( $_POST, 'status' ) ),
			'payment_status' => sanitize_key( $this->scalar( $_POST, 'payment_status' ) ),
			'driver_name'    => sanitize_text_field( $this->scalar( $_POST, 'driver_name' ) ),
			'delivery_notes' => sanitize_textarea_field( $this->scalar( $_POST, 'delivery_notes' ) ),
		);
		if ( '1' === $this->scalar( $_POST, 'reschedule' ) ) {
			$changes['delivery_date'] = sanitize_text_field( $this->scalar( $_POST, 'delivery_date' ) );
			$changes['delivery_slot'] = sanitize_text_field( $this->scalar( $_POST, 'delivery_slot' ) );
		}
		$result = Store::update_order( $id, $changes, absint( $this->scalar( $_POST, 'version' ) ) );
		$notice = 'saved';
		if ( is_wp_error( $result ) ) {
			set_transient( 'bwb_admin_notice_' . get_current_user_id(), $result->get_error_message(), 120 );
			$notice = 'error';
		}
		wp_safe_redirect( add_query_arg( array( 'page' => 'bwb-orders', 'order_id' => $id, 'bwb_notice' => $notice ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/** Prefix spreadsheet formula cells, including formulas hidden by whitespace. */
	private function csv_cell( $value ) {
		$value = (string) $value;
		return preg_match( '/^[\x00-\x20]*[=+@\-]/', $value ) || preg_match( '/^[\t\r\n]/', $value ) ? "'" . $value : $value;
	}

	public function export_orders() {
		$this->require_supplier();
		check_admin_referer( 'bwb_export' );
		$filters = $this->filters( $_POST );
		$filters['page'] = 1;
		$filters['per_page'] = 100;
		$result = Store::list_orders( $filters );
		if ( $result['total'] > 10000 ) {
			wp_die( esc_html__( 'This export contains more than 10,000 orders. Narrow the date, status or search filters and export again.', 'bottled-water-booking' ), '', array( 'response' => 400, 'back_link' => true ) );
		}
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="water-orders-' . gmdate( 'Y-m-d' ) . '.csv"' );
		header( 'X-Content-Type-Options: nosniff' );
		$out = fopen( 'php://output', 'w' );
		if ( false === $out ) {
			wp_die( esc_html__( 'Could not open the export stream.', 'bottled-water-booking' ) );
		}
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv( $out, array( 'Reference', 'Customer', 'Email', 'Phone', 'Address', 'Postcode', 'Delivery date', 'Delivery slot', 'Items', 'Subtotal (minor units)', 'Delivery fee (minor units)', 'Total (minor units)', 'Currency', 'Status', 'Payment', 'Driver', 'Customer notes', 'Internal delivery notes', 'Created', 'Updated' ), ',', '"', '' );
		do {
			foreach ( $result['orders'] as $order ) {
				$items = array();
				foreach ( $order['items'] as $item ) {
					$items[] = $item['name'] . ' x ' . $item['quantity'];
				}
				$row = array( $order['reference'], $order['customer_name'], $order['email'], $order['phone'], $order['address'], $order['postcode'], $order['delivery_date'], $order['delivery_slot'], implode( '; ', $items ), $order['subtotal_minor'], $order['delivery_fee_minor'], $order['total_minor'], $order['currency'], $order['status'], $order['payment_status'], $order['driver_name'], $order['notes'], $order['delivery_notes'], $order['created_at'], $order['updated_at'] );
				fputcsv( $out, array_map( array( $this, 'csv_cell' ), $row ), ',', '"', '' );
			}
			++$filters['page'];
			$result = $filters['page'] <= (int) ceil( $result['total'] / 100 ) ? Store::list_orders( $filters ) : array( 'orders' => array(), 'total' => 0 );
		} while ( ! empty( $result['orders'] ) );
		fclose( $out );
		exit;
	}

	public function settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to change these settings.', 'bottled-water-booking' ), '', array( 'response' => 403 ) );
		}
		$s = Store::settings();
		$products = $s['products'];
		$rows = min( 10, max( 6, count( $products ) + 1 ) );
		?>
		<div class="wrap bwb-admin bwb-settings">
			<?php $this->header( __( 'Supply settings', 'bottled-water-booking' ), __( 'Set up your products, delivery schedule and customer communications.', 'bottled-water-booking' ) ); ?>
			<?php settings_errors(); ?>
			<form method="post" action="options.php">
				<?php settings_fields( 'bwb_settings_group' ); ?>
				<section class="bwb-panel bwb-settings-panel"><h2><?php esc_html_e( 'Business & pricing', 'bottled-water-booking' ); ?></h2><div class="bwb-settings-grid"><div><label for="bwb-business-name"><?php esc_html_e( 'Business name', 'bottled-water-booking' ); ?></label><input type="text" id="bwb-business-name" name="bwb_settings[business_name]" value="<?php echo esc_attr( $s['business_name'] ); ?>" maxlength="120" required></div><div><label for="bwb-currency"><?php esc_html_e( 'Currency code', 'bottled-water-booking' ); ?></label><input type="text" id="bwb-currency" name="bwb_settings[currency]" value="<?php echo esc_attr( $s['currency'] ); ?>" pattern="[A-Za-z]{3}" maxlength="3" required><p class="description"><?php esc_html_e( 'Three-letter code, for example USD, INR or AED. Prices use two decimal places.', 'bottled-water-booking' ); ?></p></div><div><label for="bwb-delivery-fee"><?php esc_html_e( 'Delivery fee (minor units)', 'bottled-water-booking' ); ?></label><input type="number" id="bwb-delivery-fee" name="bwb_settings[delivery_fee_minor]" value="<?php echo esc_attr( $s['delivery_fee_minor'] ); ?>" min="0" max="100000000" step="1" required><p class="description"><?php esc_html_e( 'Enter 200 for 2.00. Set 0 for free delivery.', 'bottled-water-booking' ); ?></p></div></div></section>
				<section class="bwb-panel bwb-settings-panel"><h2><?php esc_html_e( 'Product catalog', 'bottled-water-booking' ); ?></h2><p class="description bwb-settings-intro"><?php esc_html_e( 'Keep product IDs stable. Use a new ID for a new product. Blank rows are ignored; uncheck Available to stop new orders. Existing orders keep their original prices.', 'bottled-water-booking' ); ?></p><div class="bwb-table-scroll"><table class="widefat bwb-products-table"><thead><tr><th><?php esc_html_e( 'Product ID', 'bottled-water-booking' ); ?></th><th><?php esc_html_e( 'Product name', 'bottled-water-booking' ); ?></th><th><?php esc_html_e( 'Size / description', 'bottled-water-booking' ); ?></th><th><?php esc_html_e( 'Price (minor units)', 'bottled-water-booking' ); ?></th><th><?php esc_html_e( 'Available', 'bottled-water-booking' ); ?></th></tr></thead><tbody>
				<?php for ( $i = 0; $i < $rows; ++$i ) : $p = isset( $products[ $i ] ) ? $products[ $i ] : array( 'id' => '', 'name' => '', 'size' => '', 'price_minor' => '', 'active' => false ); ?>
				<tr><td><label class="screen-reader-text" for="bwb-product-id-<?php echo esc_attr( $i ); ?>"><?php echo esc_html( sprintf( __( 'Product %d ID', 'bottled-water-booking' ), $i + 1 ) ); ?></label><input type="text" id="bwb-product-id-<?php echo esc_attr( $i ); ?>" name="bwb_settings[products][<?php echo esc_attr( $i ); ?>][id]" value="<?php echo esc_attr( $p['id'] ); ?>" pattern="[a-z0-9][a-z0-9_-]{0,39}" maxlength="40" placeholder="water-20l"></td><td><label class="screen-reader-text" for="bwb-product-name-<?php echo esc_attr( $i ); ?>"><?php echo esc_html( sprintf( __( 'Product %d name', 'bottled-water-booking' ), $i + 1 ) ); ?></label><input type="text" id="bwb-product-name-<?php echo esc_attr( $i ); ?>" name="bwb_settings[products][<?php echo esc_attr( $i ); ?>][name]" value="<?php echo esc_attr( $p['name'] ); ?>" maxlength="120"></td><td><label class="screen-reader-text" for="bwb-product-size-<?php echo esc_attr( $i ); ?>"><?php echo esc_html( sprintf( __( 'Product %d size', 'bottled-water-booking' ), $i + 1 ) ); ?></label><input type="text" id="bwb-product-size-<?php echo esc_attr( $i ); ?>" name="bwb_settings[products][<?php echo esc_attr( $i ); ?>][size]" value="<?php echo esc_attr( $p['size'] ); ?>" maxlength="80" placeholder="20 L"></td><td><label class="screen-reader-text" for="bwb-product-price-<?php echo esc_attr( $i ); ?>"><?php echo esc_html( sprintf( __( 'Product %d price in minor units', 'bottled-water-booking' ), $i + 1 ) ); ?></label><input type="number" id="bwb-product-price-<?php echo esc_attr( $i ); ?>" name="bwb_settings[products][<?php echo esc_attr( $i ); ?>][price_minor]" value="<?php echo esc_attr( $p['price_minor'] ); ?>" min="0" max="100000000" step="1" placeholder="500"></td><td><input type="hidden" name="bwb_settings[products][<?php echo esc_attr( $i ); ?>][active]" value="0"><label><input type="checkbox" name="bwb_settings[products][<?php echo esc_attr( $i ); ?>][active]" value="1" <?php checked( (bool) $p['active'] ); ?>><span class="screen-reader-text"><?php echo esc_html( sprintf( __( 'Product %d available for ordering', 'bottled-water-booking' ), $i + 1 ) ); ?></span></label></td></tr>
				<?php endfor; ?>
				</tbody></table></div><p class="description"><?php esc_html_e( 'All prices use minor units: 500 means 5.00 in your chosen currency. Deposits and taxes are not calculated separately; include them in the product price if needed.', 'bottled-water-booking' ); ?></p></section>
				<section class="bwb-panel bwb-settings-panel"><h2><?php esc_html_e( 'Delivery schedule', 'bottled-water-booking' ); ?></h2><div class="bwb-settings-grid"><div><label for="bwb-lead-days"><?php esc_html_e( 'Minimum lead time (days)', 'bottled-water-booking' ); ?></label><input type="number" id="bwb-lead-days" name="bwb_settings[lead_days]" value="<?php echo esc_attr( $s['lead_days'] ); ?>" min="0" max="30" step="1" required><p class="description"><?php esc_html_e( '0 allows same-day orders; 1 starts tomorrow.', 'bottled-water-booking' ); ?></p></div><div><label for="bwb-max-days"><?php esc_html_e( 'Booking window (days ahead)', 'bottled-water-booking' ); ?></label><input type="number" id="bwb-max-days" name="bwb_settings[max_days]" value="<?php echo esc_attr( $s['max_days'] ); ?>" min="1" max="90" step="1" required><p class="description"><?php esc_html_e( 'Must be greater than or equal to the minimum lead time.', 'bottled-water-booking' ); ?></p></div></div><div class="bwb-slot-field"><label for="bwb-slots"><?php esc_html_e( 'Delivery time slots', 'bottled-water-booking' ); ?></label><textarea id="bwb-slots" name="bwb_settings[slots_text]" rows="5" required><?php echo esc_textarea( implode( "\n", $s['slots'] ) ); ?></textarea><p class="description"><?php esc_html_e( 'One slot per line. These labels are shown to customers. The schedule uses your WordPress site timezone.', 'bottled-water-booking' ); ?> <strong><?php echo esc_html( wp_timezone_string() ); ?></strong></p></div></section>
				<section class="bwb-panel bwb-settings-panel"><h2><?php esc_html_e( 'Order notifications', 'bottled-water-booking' ); ?></h2><div class="bwb-settings-grid"><div><label for="bwb-notification-email"><?php esc_html_e( 'Supplier notification email', 'bottled-water-booking' ); ?></label><input type="email" id="bwb-notification-email" name="bwb_settings[notification_email]" value="<?php echo esc_attr( $s['notification_email'] ); ?>" maxlength="190"><p class="description"><?php esc_html_e( 'New order alerts are sent to this address.', 'bottled-water-booking' ); ?></p></div></div><p><input type="hidden" name="bwb_settings[notify_customer]" value="0"><label><input type="checkbox" name="bwb_settings[notify_customer]" value="1" <?php checked( (bool) $s['notify_customer'] ); ?>> <?php esc_html_e( 'Email customers their booking confirmation and delivery status updates', 'bottled-water-booking' ); ?></label></p><p class="description"><?php esc_html_e( 'Email delivery depends on your WordPress mail configuration. Test it before taking live orders.', 'bottled-water-booking' ); ?></p></section>
				<?php submit_button( __( 'Save supply settings', 'bottled-water-booking' ) ); ?>
			</form>
			<section class="bwb-setup-tip"><h2><?php esc_html_e( 'Add ordering to your website', 'bottled-water-booking' ); ?></h2><p><?php esc_html_e( 'Add this shortcode to a WordPress page:', 'bottled-water-booking' ); ?> <code>[bwb_order_form]</code></p><p><?php esc_html_e( 'For a separate order tracking page, use:', 'bottled-water-booking' ); ?> <code>[bwb_order_tracking]</code></p><p><?php esc_html_e( 'Give delivery staff the Water Supplier role under Users. They can manage orders without changing your site settings.', 'bottled-water-booking' ); ?></p></section>
		</div>
		<?php
	}
}

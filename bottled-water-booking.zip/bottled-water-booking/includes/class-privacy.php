<?php
namespace BWB;

defined( 'ABSPATH' ) || exit;

/** Integrates with Tools > Export/Erase Personal Data. */
class Privacy {
    public function __construct() {
        add_filter( 'wp_privacy_personal_data_exporters', array( $this, 'exporters' ) );
        add_filter( 'wp_privacy_personal_data_erasers', array( $this, 'erasers' ) );
        add_action( 'admin_init', array( $this, 'policy' ) );
    }

    public function exporters( $exporters ) {
        $exporters['bwb-orders'] = array( 'exporter_friendly_name' => __( 'Water supply orders', 'bottled-water-booking' ), 'callback' => array( $this, 'export' ) );
        return $exporters;
    }

    public function erasers( $erasers ) {
        $erasers['bwb-orders'] = array( 'eraser_friendly_name' => __( 'Water supply orders', 'bottled-water-booking' ), 'callback' => array( $this, 'erase' ) );
        return $erasers;
    }

    public function export( $email, $page = 1 ) {
        global $wpdb;
        if ( ! is_email( $email ) ) {
            return array( 'data' => array(), 'done' => true );
        }
        $page = max( 1, (int) $page );
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}bwb_orders WHERE email = %s ORDER BY id ASC LIMIT 100 OFFSET %d", sanitize_email( $email ), ( $page - 1 ) * 100 ), ARRAY_A );
        $data = array();
        $fields = array( 'reference' => 'Order reference', 'customer_name' => 'Name', 'email' => 'Email', 'phone' => 'Phone', 'address' => 'Delivery address', 'postcode' => 'Postal code', 'delivery_date' => 'Delivery date', 'delivery_slot' => 'Delivery window', 'notes' => 'Customer notes', 'status' => 'Order status', 'payment_status' => 'Payment status', 'created_at' => 'Created at' );
        foreach ( $rows as $row ) {
            $entry = array();
            foreach ( $fields as $key => $label ) {
                $entry[] = array( 'name' => $label, 'value' => $row[ $key ] );
            }
            $items = json_decode( $row['items'], true );
            if ( is_array( $items ) ) {
                foreach ( $items as $item ) {
                    $entry[] = array( 'name' => 'Item', 'value' => $item['name'] . ' × ' . $item['quantity'] );
                }
            }
            $entry[] = array( 'name' => 'Total', 'value' => Store::money( $row['total_minor'], $row['currency'] ) );
            $data[] = array( 'group_id' => 'bwb-orders', 'group_label' => __( 'Water supply orders', 'bottled-water-booking' ), 'item_id' => 'bwb-' . $row['id'], 'data' => $entry );
        }
        return array( 'data' => $data, 'done' => count( $rows ) < 100 );
    }

    public function erase( $email, $page = 1 ) {
        global $wpdb;
        if ( ! is_email( $email ) ) {
            return array( 'items_removed' => false, 'items_retained' => false, 'messages' => array(), 'done' => true );
        }
        // Select the first remaining matching batch: anonymization removes matches.
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT id,status FROM {$wpdb->prefix}bwb_orders WHERE email = %s ORDER BY id ASC LIMIT 100", sanitize_email( $email ) ), ARRAY_A );
        $removed = false;
        $retained = false;
        $messages = array();
        foreach ( $rows as $row ) {
            // Explicit privacy erasure also revokes tracking keys, including active orders.
            $result = $wpdb->query( $wpdb->prepare(
                "UPDATE {$wpdb->prefix}bwb_orders SET customer_id=0, customer_name=%s, email='', phone='', address='', postcode='', notes='', delivery_notes='', driver_name='', access_token_hash=%s, updated_at=%s, version=version+1 WHERE id=%d",
                'Erased customer', hash( 'sha256', wp_generate_password( 64, true, true ) ), current_time( 'mysql' ), $row['id']
            ) );
            if ( false === $result ) {
                $retained = true;
            } else {
                $removed = true;
            }
        }
        if ( $retained ) {
            $messages[] = __( 'Some water orders could not be anonymized. Please retry the erasure request.', 'bottled-water-booking' );
        }
        return array( 'items_removed' => $removed, 'items_retained' => $retained, 'messages' => $messages, 'done' => count( $rows ) < 100 || $retained );
    }

    public function policy() {
        if ( function_exists( 'wp_add_privacy_policy_content' ) ) {
            wp_add_privacy_policy_content( 'AquaRoute – Bottled Water Booking', wp_kses_post(
                '<p>When you place a water order, we store your name, email, phone number, delivery address, postal code, delivery preferences, order items and notes. We use them to fulfill and manage your delivery. Your tracking key gives access to the order status; keep it private. We send order email using the site’s configured WordPress mail service when enabled.</p>' .
                '<p>We use a salted hash of the connection IP address for short-lived automated-request limits. WordPress removes expired rate-limit entries through its scheduled cleanup. Booking data stays in this WordPress database until an administrator erases it or removes the plugin with data deletion explicitly enabled. WordPress personal data export and erasure tools include these orders. Erasure anonymizes contact and delivery details and revokes tracking access while retaining transaction totals. Administrators should define their own retention period and delivery-area and cancellation policies.</p>'
            ) );
        }
    }
}

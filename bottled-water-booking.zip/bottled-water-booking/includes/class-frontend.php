<?php
/** Customer booking, tracking, and public API. */
namespace BWB;

defined('ABSPATH') || exit;

class Frontend {
    public function __construct() {
        add_shortcode('bwb_order_form', array($this, 'booking_shortcode'));
        add_shortcode('bwb_order_tracking', array($this, 'tracking_shortcode'));
        add_action('wp_enqueue_scripts', array($this, 'register_assets'));
        add_action('rest_api_init', array($this, 'register_routes'));
        add_action('wp_ajax_bwb_session', array($this, 'ajax_session'));
        add_action('wp_ajax_nopriv_bwb_session', array($this, 'ajax_session'));
    }

    public function register_assets() {
        wp_register_style('bwb-frontend', BWB_URL . 'assets/frontend.css', array(), BWB_VERSION);
        wp_register_script('bwb-frontend', BWB_URL . 'assets/frontend.js', array(), BWB_VERSION, true);
        $post = get_queried_object();
        if ($post instanceof \WP_Post && (has_shortcode($post->post_content, 'bwb_order_form') || has_shortcode($post->post_content, 'bwb_order_tracking'))) {
            wp_enqueue_style('bwb-frontend');
            wp_enqueue_script('bwb-frontend');
        }
    }

    private function assets() {
        $this->register_assets();
        wp_enqueue_style('bwb-frontend');
        wp_enqueue_script('bwb-frontend');
        // A shortcode in a widget or a custom template can render after wp_head.
        if (did_action('wp_head') && !wp_style_is('bwb-frontend', 'done')) {
            ob_start();
            wp_print_styles(array('bwb-frontend'));
            return ob_get_clean();
        }
        return '';
    }

    private function config() {
        $settings = Store::settings();
        return array(
            'api' => esc_url_raw(rest_url('bwb/v1/')),
            'sessionUrl' => esc_url_raw(admin_url('admin-ajax.php?action=bwb_session')),
            'currency' => $settings['currency'],
            'deliveryFee' => (int) $settings['delivery_fee_minor'],
            'products' => array_values(Store::products()),
            'statuses' => Store::statuses(),
        );
    }

    public function booking_shortcode() {
        $asset_markup = $this->assets();
        $settings = Store::settings();
        $products = Store::products();
        $bounds = Store::date_bounds();
        $uid = wp_unique_id('bwb-');
        ob_start();
        ?>
        <div class="bwb-app" data-bwb-app data-config="<?php echo esc_attr(wp_json_encode($this->config())); ?>">
            <div class="bwb-brand"><span class="bwb-drop" aria-hidden="true"></span><span><?php echo esc_html($settings['business_name']); ?></span><span class="bwb-brand-tag">WATER DELIVERY</span></div>
            <section class="bwb-hero" aria-labelledby="<?php echo esc_attr($uid); ?>title">
                <div class="bwb-hero-copy"><p class="bwb-eyebrow">A LITTLE REFRESHMENT, DELIVERED.</p><h2 id="<?php echo esc_attr($uid); ?>title">Good water.<br>A doorstep away.</h2><p>Choose your water, pick a delivery slot, and leave the heavy lifting to us.</p><div class="bwb-perks"><span><b aria-hidden="true">✓</b> Convenient delivery</span><span><b aria-hidden="true">✓</b> Pay on delivery</span></div></div>
                <div class="bwb-hero-art" aria-hidden="true"><div class="bwb-orbit"></div><div class="bwb-bottle"><div class="bwb-cap"></div><div class="bwb-neck"></div><div class="bwb-bottle-body"><div class="bwb-bottle-shine"></div><span>PURE<br><small>every day.</small></span></div></div><span class="bwb-art-note">Everyday hydration.<br>Made simple.</span></div>
            </section>
            <div class="bwb-notice" data-message role="status" aria-live="polite" hidden></div>
            <section class="bwb-success" data-success tabindex="-1" hidden></section>
            <?php if (!$products || empty($settings['slots'])) : ?>
                <div class="bwb-empty"><h3>We’re getting ready to deliver.</h3><p>Online ordering is currently unavailable. Please check back soon.</p></div>
            <?php else : ?>
            <form data-order-form class="bwb-booking">
                <div class="bwb-main">
                    <section class="bwb-section" aria-labelledby="<?php echo esc_attr($uid); ?>products"><div class="bwb-step-heading"><span>01</span><div><h3 id="<?php echo esc_attr($uid); ?>products">Choose your water</h3><p>Stock up for home, work, or whatever’s next.</p></div></div>
                        <div class="bwb-products">
                        <?php foreach ($products as $index => $product) : ?>
                            <div class="bwb-product" data-product="<?php echo esc_attr($product['id']); ?>">
                                <div class="bwb-product-icon" aria-hidden="true"><span></span></div>
                                <div class="bwb-product-details"><span class="bwb-product-size"><?php echo esc_html($product['size']); ?></span><h4><?php echo esc_html($product['name']); ?></h4><p><?php echo esc_html(Store::money($product['price_minor'], $settings['currency'])); ?> <small>/ unit</small></p></div>
                                <div class="bwb-quantity"><button type="button" data-quantity-change="-1" aria-label="<?php echo esc_attr(sprintf('Remove one %s', $product['name'])); ?>">−</button><input type="number" min="0" max="99" step="1" value="0" data-quantity inputmode="numeric" aria-label="<?php echo esc_attr(sprintf('Quantity of %s', $product['name'])); ?>"><button type="button" data-quantity-change="1" aria-label="<?php echo esc_attr(sprintf('Add one %s', $product['name'])); ?>">+</button></div>
                            </div>
                        <?php endforeach; ?>
                        </div>
                    </section>
                    <section class="bwb-section" aria-labelledby="<?php echo esc_attr($uid); ?>delivery"><div class="bwb-step-heading"><span>02</span><div><h3 id="<?php echo esc_attr($uid); ?>delivery">Make it your delivery</h3><p>Tell us where and when to bring your order.</p></div></div>
                        <div class="bwb-fields">
                            <label>Full name <span aria-hidden="true">*</span><input type="text" name="customer_name" autocomplete="name" maxlength="120" required placeholder="Your full name"></label>
                            <label>Email address <span aria-hidden="true">*</span><input type="email" name="email" autocomplete="email" maxlength="190" required placeholder="you@example.com"></label>
                            <label>Phone number <span aria-hidden="true">*</span><input type="tel" name="phone" autocomplete="tel" maxlength="40" required placeholder="Delivery contact number"></label>
                            <label>Postal / ZIP code <span aria-hidden="true">*</span><input type="text" name="postcode" autocomplete="postal-code" maxlength="20" required placeholder="Postal or ZIP code"></label>
                            <label class="bwb-field-wide">Delivery address <span aria-hidden="true">*</span><textarea name="address" autocomplete="street-address" maxlength="1000" rows="2" required placeholder="Building, street, area, and city"></textarea></label>
                            <label>Delivery date <span aria-hidden="true">*</span><input type="date" name="delivery_date" min="<?php echo esc_attr($bounds['min']); ?>" max="<?php echo esc_attr($bounds['max']); ?>" required></label>
                            <label>Delivery slot <span aria-hidden="true">*</span><select name="delivery_slot" required><option value="">Choose a time slot</option><?php foreach ($settings['slots'] as $slot) : ?><option value="<?php echo esc_attr($slot); ?>"><?php echo esc_html($slot); ?></option><?php endforeach; ?></select></label>
                            <label class="bwb-field-wide">Delivery instructions <small>(optional)</small><textarea name="notes" maxlength="2000" rows="2" placeholder="Gate number, a nearby landmark, or anything we should know"></textarea></label>
                            <div class="bwb-trap" aria-hidden="true"><label>Website<input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
                        </div>
                    </section>
                </div>
                <aside class="bwb-summary" aria-labelledby="<?php echo esc_attr($uid); ?>summary"><p class="bwb-eyebrow">YOUR REFRESHMENT, SORTED</p><h3 id="<?php echo esc_attr($uid); ?>summary">Order summary</h3><div data-cart-lines class="bwb-cart-lines"><p class="bwb-muted">Add some water to get started.</p></div><div class="bwb-summary-row"><span>Subtotal</span><span data-subtotal><?php echo esc_html(Store::money(0)); ?></span></div><div class="bwb-summary-row"><span>Delivery</span><span data-delivery><?php echo esc_html(Store::money($settings['delivery_fee_minor'])); ?></span></div><div class="bwb-total"><span>Total</span><strong data-total><?php echo esc_html(Store::money(0)); ?></strong></div><div class="bwb-payment"><span aria-hidden="true">▣</span><div><strong>Cash on delivery</strong><small>Pay when your water arrives.</small></div></div><button type="submit" class="bwb-button" data-submit>Place my order <span aria-hidden="true">→</span></button><p class="bwb-fine-print">Delivery is subject to supplier confirmation. Your details are used to fulfill your order.<?php $privacy_url = get_privacy_policy_url(); if ($privacy_url) : ?> <a href="<?php echo esc_url($privacy_url); ?>">Privacy policy</a>.<?php endif; ?></p></aside>
            </form>
            <?php endif; ?>
            <?php echo $this->tracking_markup($uid); // Escaped within helper. ?>
            <p class="bwb-footer">Simple ordering. A refreshing everyday routine.</p>
            <noscript><p class="bwb-notice">Please enable JavaScript to place and track a water order.</p></noscript>
        </div>
        <?php
        return $asset_markup . ob_get_clean();
    }

    public function tracking_shortcode() {
        $asset_markup = $this->assets();
        return $asset_markup . '<div class="bwb-app bwb-track-only" data-bwb-app data-config="' . esc_attr(wp_json_encode($this->config())) . '">' . $this->tracking_markup(wp_unique_id('bwb-track-')) . '<noscript><p>Please enable JavaScript to track your order.</p></noscript></div>';
    }

    private function tracking_markup($uid) {
        ob_start(); ?>
        <section class="bwb-tracking" aria-labelledby="<?php echo esc_attr($uid); ?>tracking"><div class="bwb-tracking-intro"><p class="bwb-eyebrow">ALREADY ORDERED?</p><h3 id="<?php echo esc_attr($uid); ?>tracking">Follow your delivery</h3><p>Use the reference and private tracking key from your confirmation.</p></div><form data-track-form><label>Order reference<input name="reference" type="text" required maxlength="40" autocapitalize="characters" placeholder="Your order reference"></label><label>Private tracking key<input name="token" type="password" required maxlength="128" autocomplete="off" placeholder="Your private key"></label><button type="submit" class="bwb-button bwb-button-secondary">Track order <span aria-hidden="true">→</span></button></form><div data-track-message class="bwb-notice" role="status" aria-live="polite" hidden></div><div data-tracking-result tabindex="-1" hidden></div></section>
        <?php return ob_get_clean();
    }

    public function register_routes() {
        register_rest_route('bwb/v1', '/session', array('methods' => 'GET', 'permission_callback' => array($this, 'same_origin'), 'callback' => array($this, 'session')));
        register_rest_route('bwb/v1', '/orders', array('methods' => 'POST', 'permission_callback' => array($this, 'public_permission'), 'callback' => array($this, 'create')));
        register_rest_route('bwb/v1', '/track', array('methods' => 'POST', 'permission_callback' => array($this, 'public_permission'), 'callback' => array($this, 'track')));
    }

    public function same_origin() {
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? wp_unslash($_SERVER['HTTP_ORIGIN']) : '';
        if ($origin) {
            $allowed = array($this->origin(home_url()), $this->origin(rest_url()), $this->origin(admin_url()));
            if (!in_array($this->origin($origin), $allowed, true)) {
                return new \WP_Error('bwb_origin', 'Please submit your request from this website.', array('status' => 403));
            }
        } elseif (isset($_SERVER['HTTP_SEC_FETCH_SITE']) && 'cross-site' === $_SERVER['HTTP_SEC_FETCH_SITE']) {
            return new \WP_Error('bwb_origin', 'Please submit your request from this website.', array('status' => 403));
        }
        return true;
    }

    private function origin($url) {
        $parts = wp_parse_url($url);
        if (!is_array($parts) || empty($parts['host']) || empty($parts['scheme'])) {
            return '';
        }
        $port = isset($parts['port']) ? (int) $parts['port'] : ('https' === strtolower($parts['scheme']) ? 443 : 80);
        return strtolower($parts['scheme'] . '://' . $parts['host']) . ':' . $port;
    }

    public function session() {
        $limit = $this->rate_limit('session', 120, MINUTE_IN_SECONDS);
        if (is_wp_error($limit)) {
            return $limit;
        }
        $response = new \WP_REST_Response(array('nonce' => wp_create_nonce('wp_rest')));
        $response->header('Cache-Control', 'no-store, no-cache, must-revalidate, private');
        return $response;
    }

    public function ajax_session() {
        nocache_headers();
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        $permission = $this->same_origin();
        if (is_wp_error($permission)) {
            wp_send_json(array('message' => $permission->get_error_message()), 403);
        }
        $limit = $this->rate_limit('session', 120, MINUTE_IN_SECONDS);
        if (is_wp_error($limit)) {
            wp_send_json(array('message' => $limit->get_error_message()), 429);
        }
        wp_send_json(array('nonce' => wp_create_nonce('wp_rest')));
    }

    public function public_permission($request) {
        $origin = $this->same_origin();
        if (is_wp_error($origin)) {
            return $origin;
        }
        if (strlen($request->get_body()) > 32768) {
            return new \WP_Error('bwb_too_large', 'This request is too large.', array('status' => 413));
        }
        if (!wp_verify_nonce($request->get_header('X-WP-Nonce'), 'wp_rest')) {
            return new \WP_Error('bwb_nonce', 'Your session expired. Please reload this page and try again.', array('status' => 403));
        }
        $is_order = false !== strpos($request->get_route(), '/orders');
        return $this->rate_limit($is_order ? 'order' : 'track', $is_order ? 8 : 40, 15 * MINUTE_IN_SECONDS);
    }

    private function rate_limit($kind, $limit, $period) {
        $ip = isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : 'unknown';
        $key = 'bwb_rl_' . $kind . '_' . substr(hash_hmac('sha256', $ip, wp_salt('nonce')), 0, 32);
        $data = get_transient($key);
        $now = time();
        if (!is_array($data) || empty($data['until']) || $data['until'] <= $now) {
            $data = array('count' => 0, 'until' => $now + $period);
        }
        if ((int) $data['count'] >= $limit) {
            return new \WP_Error('bwb_rate_limit', 'Too many requests. Please wait a few minutes before trying again.', array('status' => 429));
        }
        $data['count']++;
        set_transient($key, $data, max(1, $data['until'] - $now));
        return true;
    }

    public function create($request) {
        $input = $request->get_json_params();
        if (!is_array($input)) {
            return new \WP_Error('bwb_invalid_request', 'Please send a valid order.', array('status' => 400));
        }
        $result = Store::create_order($input);
        if (is_wp_error($result)) {
            $data = $result->get_error_data();
            if (!is_array($data) || !isset($data['status'])) {
                $result->add_data(array('status' => 400));
            }
            return $result;
        }
        $public = Store::track_order($result['order']['reference'], $result['token']);
        if (is_wp_error($public)) {
            return new \WP_Error('bwb_tracking_unavailable', 'Your order was saved, but tracking is temporarily unavailable. Please contact the supplier before placing another order.', array('status' => 500));
        }
        $response = new \WP_REST_Response(array('order' => $public, 'token' => $result['token']), 201);
        $response->header('Cache-Control', 'no-store, private');
        return $response;
    }

    public function track($request) {
        $input = $request->get_json_params();
        if (!is_array($input) || !isset($input['reference'], $input['token']) || !is_string($input['reference']) || !is_string($input['token']) || strlen($input['reference']) > 40 || strlen($input['token']) > 128) {
            return new \WP_Error('bwb_invalid_tracking', 'Enter your order reference and private tracking key.', array('status' => 400));
        }
        $result = Store::track_order(trim($input['reference']), trim($input['token']));
        if (is_wp_error($result)) {
            $data = $result->get_error_data();
            if (!is_array($data) || !isset($data['status'])) {
                $result->add_data(array('status' => 404));
            }
            return $result;
        }
        $response = new \WP_REST_Response(array('order' => $result));
        $response->header('Cache-Control', 'no-store, private');
        return $response;
    }
}

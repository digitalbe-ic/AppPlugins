<?php
/** Data is retained by default. Opt in in wp-config.php before deleting the plugin. */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

if ( ! defined( 'BWB_DELETE_DATA_ON_UNINSTALL' ) || true !== BWB_DELETE_DATA_ON_UNINSTALL ) {
    return;
}

function bwb_remove_site_data() {
    global $wpdb;
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}bwb_orders" );
    delete_option( 'bwb_settings' );
    delete_option( 'bwb_db_version' );
    $role = get_role( 'administrator' );
    if ( $role ) {
        $role->remove_cap( 'bwb_manage_orders' );
    }
    // Preserve any user assigned to this role; removing a role does not delete users.
    remove_role( 'bwb_supplier' );
    $like = $wpdb->esc_like( '_transient_bwb_' ) . '%';
    $timeout_like = $wpdb->esc_like( '_transient_timeout_bwb_' ) . '%';
    $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $like, $timeout_like ) );
}

// WordPress deletes plugins network-wide. Explicit opt-in removes every site's data.
if ( is_multisite() ) {
    $offset = 0;
    do {
        $site_ids = get_sites( array( 'fields' => 'ids', 'number' => 100, 'offset' => $offset, 'orderby' => 'id', 'order' => 'ASC' ) );
        foreach ( $site_ids as $site_id ) {
            switch_to_blog( (int) $site_id );
            bwb_remove_site_data();
            restore_current_blog();
        }
        $offset += 100;
    } while ( count( $site_ids ) === 100 );
} else {
    bwb_remove_site_data();
}

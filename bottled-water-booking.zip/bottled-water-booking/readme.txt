=== AquaRoute – Bottled Water Booking & Supply ===
Contributors: aquaroute
Tags: water delivery, booking, orders, delivery, supplier
Requires at least: 6.2
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Customer water ordering and a supplier dashboard for deliveries. Standalone; no WooCommerce required.

== Description ==

Use [bwb_order_form] on a WordPress page to accept bottled water orders. Customers choose products, quantities, delivery date and slot, enter contact details, and receive a reference and private tracking key.

The Water Supply dashboard lets authorized staff search and filter orders, assign a driver by name, reschedule deliveries, record payments, advance order status and export CSV files.

Features:
* Responsive customer form, live order totals and private order tracking.
* Editable product catalogue, currency, delivery charge, lead time and delivery windows.
* Pending, confirmed, out for delivery, delivered and cancelled statuses.
* Cash on delivery with manual paid/unpaid recording.
* Administrator settings and a restricted Water Supplier role for order handling.
* Customer and supplier email notifications through WordPress mail.
* Server-side prices, duplicate submission protection, rate limits and stale update detection.
* WordPress personal data export/erasure integration.

== Installation ==

1. In WordPress, open Plugins > Add New Plugin > Upload Plugin.
2. Upload bottled-water-booking.zip, install, and activate it.
3. Open Water Supply > Settings. Set products, prices, delivery charge, booking window, slots and notification email.
4. Create a page called Order Water and insert a Shortcode block containing [bwb_order_form]. Publish the page.
5. Optionally create a separate tracking page with [bwb_order_tracking]. Tracking is already included in the order form.
6. In Users, assign delivery staff the Water Supplier role. They can manage all water orders but cannot edit plugin settings.
7. Place a trial order, check mail delivery, then confirm, dispatch and deliver it in Water Supply > Orders.

Activate separately on individual sites in a multisite network. Network activation is not supported.

== Frequently Asked Questions ==

= Does this process online payments? =
No. Orders use cash on delivery. Staff manually record payment as paid or unpaid. No payment gateway, card processing, tax calculation, refunds or accounting integration is included.

= How do prices work? =
All prices are whole-number minor units with a fixed two-decimal scale: 500 means 5.00 in the selected currency, and 200 means 2.00. Use a currency that uses two decimal places. Currency changes affect new orders only; historical orders retain their original currency and price snapshots. Revenue totals show delivered, paid orders in the current currency only.

= Can customers check their order? =
Yes. The confirmation shows a reference, private tracking key and a tracking link. Keep the key safe: a reference by itself cannot retrieve an order. Only a hash of the key is stored. Staff cannot recover it. Customer emails include the key when email notifications are enabled. A lost key requires contacting the supplier.

= Do emails require configuration? =
Emails use wp_mail and your site's existing mail setup. Configure and test a suitable mail transport. A successful booking does not guarantee email delivery; the on-screen confirmation is authoritative. No external email service is bundled.

= Does this include subscriptions or route optimization? =
This version handles individual orders and manual driver assignments. Recurring subscriptions, bottle deposits/returns, inventory, delivery capacity, service-area validation, GPS routing, SMS and WhatsApp are not included. Date and time slot choices are requests subject to supplier confirmation.

= Can multiple suppliers run separate businesses? =
All Water Supplier users can see and manage the same site's orders. This version does not separate vendors or create independent supplier accounts.

= What happens when the plugin is removed? =
Deactivation and deletion retain orders and settings by default. For irreversible deletion, add define('BWB_DELETE_DATA_ON_UNINSTALL', true); to wp-config.php before deleting the plugin through WordPress. Back up first. This removes order tables, settings, supplier roles and plugin capabilities. On multisite, deletion removes the plugin's data across every site in the network. Remove the constant afterward.

= How is personal data handled? =
Orders are stored in your WordPress database. Tools > Export Personal Data and Erase Personal Data include water orders. Erasure anonymizes contact details, customer and internal notes, driver names and addresses, and revokes tracking access. Transaction amounts remain. Erasing an active order removes the address needed for delivery, so resolve active fulfillment before approving an erasure request. Privacy policy helper text is included in WordPress. Set your own retention and delivery policies.

= Does this work with caching? =
The form refreshes its security nonce with an uncached same-origin request so cached pages and signed-in customers can submit. Exclude /wp-admin/admin-ajax.php?action=bwb_session and /wp-json/bwb/v1/* from CDN/API caching. Rate limits are based on the direct connection IP; visitors behind a proxy can share limits.

== Changelog ==

= 1.0.0 =
Initial release: ordering, private tracking, supplier order management, delivery updates, settings, CSV export, mail notifications and privacy tools.
